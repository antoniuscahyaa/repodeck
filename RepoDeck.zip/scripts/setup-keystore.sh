#!/usr/bin/env bash
# Menyiapkan keystore LAMA (sama dengan SocialHub) sebagai GitHub Secrets untuk RepoDeck.
#
# Pemakaian:
#   ./setup-keystore.sh /path/ke/keystore.jks                  -> menyimpan keystore.base64.txt (isi manual ke Secrets)
#   ./setup-keystore.sh /path/ke/keystore.jks pemilik/nama-repo -> mengisi Secrets otomatis (butuh GitHub CLI: gh auth login)
#
# Secrets yang dibutuhkan workflow: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
set -euo pipefail

KS="${1:-}"
REPO="${2:-}"

if [ -z "$KS" ] || [ ! -f "$KS" ]; then
  echo "Pemakaian: $0 /path/ke/keystore.jks [pemilik/nama-repo]" >&2
  exit 1
fi

if base64 --help 2>&1 | grep -q -- '-w'; then
  B64="$(base64 -w0 "$KS")"
else
  B64="$(base64 "$KS" | tr -d '\n')"
fi

if command -v keytool >/dev/null 2>&1; then
  echo "Alias di keystore (untuk KEY_ALIAS):"
  keytool -list -keystore "$KS" 2>/dev/null | grep -i "PrivateKeyEntry" || echo "  (isi password keystore saat diminta untuk melihat daftar alias)"
  echo
fi

read -r -s -p "KEYSTORE_PASSWORD: " STORE_PASS; echo
read -r -p  "KEY_ALIAS: " KEY_ALIAS
read -r -s -p "KEY_PASSWORD (kosongkan jika sama dengan password keystore): " KEY_PASS; echo
KEY_PASS="${KEY_PASS:-$STORE_PASS}"

if [ -n "$REPO" ] && command -v gh >/dev/null 2>&1; then
  printf '%s' "$B64"        | gh secret set KEYSTORE_BASE64   --repo "$REPO"
  printf '%s' "$STORE_PASS" | gh secret set KEYSTORE_PASSWORD --repo "$REPO"
  printf '%s' "$KEY_ALIAS"  | gh secret set KEY_ALIAS         --repo "$REPO"
  printf '%s' "$KEY_PASS"   | gh secret set KEY_PASSWORD      --repo "$REPO"
  echo "Selesai: 4 Secrets terisi di $REPO."
else
  OUT="keystore.base64.txt"
  printf '%s' "$B64" > "$OUT"
  echo "Tersimpan di $OUT."
  echo "Buka GitHub > repo > Settings > Secrets and variables > Actions > New repository secret, lalu isi:"
  echo "  KEYSTORE_BASE64   = isi file $OUT"
  echo "  KEYSTORE_PASSWORD = (password keystore)"
  echo "  KEY_ALIAS         = $KEY_ALIAS"
  echo "  KEY_PASSWORD      = (password kunci)"
  echo "Hapus $OUT setelah selesai. Jangan di-commit."
fi
