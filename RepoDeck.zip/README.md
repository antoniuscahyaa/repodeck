# RepoDeck

Aplikasi Android (minSdk 29 / Android 10) untuk mengelola repository GitHub: unggah ZIP,
pantau GitHub Actions, unduh artifact, dan pasang APK hasil build. Dibuat dari fitur GitHub Manager SocialHub.

## Build
Push proyek ini ke repo GitHub. Workflow `.github/workflows/android.yml` membangun APK otomatis.

### Susunan repo
- File proyek langsung di root repo, **atau**
- Repo hanya berisi `RepoDeck.zip` (hasil unggah dari aplikasi): workflow mengekstraknya sendiri.
Pastikan `.github/workflows/android.yml` ada di repo (file ini ada di dalam zip dan juga dikirim terpisah).

### Secrets keystore (Settings > Secrets and variables > Actions)
| Secret | Isi |
|---|---|
| `KEYSTORE_BASE64` | Keystore lama dalam base64 (`base64 -w0 nama.jks`) |
| `KEYSTORE_PASSWORD` | Password keystore |
| `KEY_ALIAS` | Alias kunci |
| `KEY_PASSWORD` | Password kunci |

Cara cepat: jalankan `scripts/setup-keystore.sh keystore-lama.jks pemilik/nama-repo` (mengisi keempat Secrets lewat GitHub CLI), atau tanpa argumen repo untuk membuat `keystore.base64.txt`.
Secrets bersifat per-repo, jadi keystore SocialHub perlu diisikan lagi di repo RepoDeck.

Tanpa `KEYSTORE_BASE64`, workflow membuat APK debug. Dengan keystore, dibuat APK release bertanda tangan.

## Pemakaian pertama
1. Buka tab **Akun**, isi username/organisasi dan Personal Access Token
   (Contents: Read and write, Actions: Read-only).
2. Tambah repo lewat tombol **+** di tab Repo (tempel link repository).
3. Pilih repo, **Pilih file ZIP**, lalu pantau build di tab Build.

## Folder unduhan
- `Download/RepoDeck/Builds/<repo>/` : artifact build (ZIP)
- `Download/RepoDeck/BuildLogs/<repo>/` : log build yang gagal
- `Android/data/com.repodeck.app/files/Download/RepoDeck/Apk/<repo>/` : APK hasil ekstraksi untuk dipasang

## Tab Lawn (khusus repo `antoniuscahyaa/lawn`)
Tab keempat untuk satu repo tetap:
- **Upload patch**: kirim satu/beberapa file ke branch `main` (folder tujuan opsional). File bernama sama diganti.
- **Workflow**: daftar `.github/workflows/*.yml`; unggah atau timpa file `.yml`.
- **Run workflow**: memicu `workflow_dispatch` pada workflow terpilih, lalu memantau statusnya.

Token: memakai token tab Akun, atau token khusus yang diisi di kartu Token pada tab ini.
Izin yang dibutuhkan: Contents (write), Actions (write), Workflows (write) untuk fine-grained PAT,
atau scope `repo` + `workflow` untuk classic PAT. Workflow harus memuat `on: workflow_dispatch:`.
