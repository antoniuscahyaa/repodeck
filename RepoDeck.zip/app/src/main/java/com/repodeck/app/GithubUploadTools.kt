package com.repodeck.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/** Ringkasan isi ZIP: jumlah file serta nama proyek Gradle bila ditemukan. */
class ZipInfo(val fileCount: Int, val rootName: String?, val appId: String?)

/**
 * Alat pemeriksaan ZIP sebelum upload (dijalankan di background thread): ukuran, tanggal ubah,
 * isi ZIP (tanpa mengekstrak ke penyimpanan), dan hash Git untuk mendeteksi file identik.
 */
object GithubUploadTools {

    private val rootRegex = Regex("""rootProject\.name\s*=\s*["']([^"']+)["']""")
    private val appIdRegex = Regex("""(?:applicationId|namespace)\s*(?:=\s*)?["']([^"']+)["']""")

    fun queryZipSize(context: Context, uri: Uri): Long {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
            } ?: -1L
        } catch (_: Exception) {
            -1L
        }
    }

    /** Tanggal ubah file (ms) bila penyedia dokumen menyediakannya; null bila tidak tersedia. */
    fun queryLastModified(context: Context, uri: Uri): Long? {
        return try {
            context.contentResolver.query(uri, arrayOf("last_modified"), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0).takeIf { value -> value > 0L } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun inspectZip(context: Context, uri: Uri): ZipInfo {
        var count = 0
        var root: String? = null
        var appId: String? = null
        context.contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null && count < 100_000) {
                    if (!entry.isDirectory) {
                        count++
                        val segments = entry.name.replace('\\', '/').split('/').filter { it.isNotEmpty() }
                        val file = segments.lastOrNull().orEmpty()
                        if (root == null && segments.size <= 2 && (file == "settings.gradle.kts" || file == "settings.gradle")) {
                            root = rootRegex.find(readText(zip))?.groupValues?.get(1)
                        } else if (appId == null && segments.size in 2..3 &&
                            (file == "build.gradle.kts" || file == "build.gradle") &&
                            segments.getOrNull(segments.size - 2) == "app"
                        ) {
                            appId = appIdRegex.find(readText(zip))?.groupValues?.get(1)
                        }
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return ZipInfo(count, root, appId)
    }

    private fun readText(zip: ZipInputStream, limit: Int = 24_000): String {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        while (out.size() < limit) {
            val n = zip.read(buffer)
            if (n < 0) break
            out.write(buffer, 0, n)
        }
        return out.toString("UTF-8")
    }

    /** SHA-1 gaya Git ("blob <ukuran>\0<isi>"), sama dengan sha yang dilaporkan GitHub untuk file di repo. */
    fun gitBlobSha(context: Context, uri: Uri, size: Long): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob $size\u0000".toByteArray(Charsets.UTF_8))
            var total = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    digest.update(buffer, 0, n)
                    total += n
                }
            } ?: return null
            if (total != size) null else digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            null
        }
    }
}
