package com.repodeck.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Halaman khusus repo "lawn": upload file baru ke branch main, ganti file workflow di
 * .github/workflows/, dan tombol untuk menjalankan workflow (workflow_dispatch).
 * Berdiri sendiri: tidak mengubah alur Repo/Build/Akun yang sudah ada.
 */
class LawnDeployPage(private val host: MainActivity, private val api: GithubApi) {

    private companion object {
        const val DEFAULT_OWNER = "antoniuscahyaa"
        const val REPO = "lawn"
        const val BRANCH = "main"
        const val WORKFLOW_DIR = ".github/workflows"
        const val MAX_BYTES = 50 * 1024 * 1024
        const val TOKEN_KEY = "lawn_token"
        const val PREF_SELECTED = "lawn_selected_workflow"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private var busy = false
    private val actionButtons = mutableListOf<TextView>()

    private var folderField: EditText? = null
    private var tokenField: EditText? = null
    private var tokenStatus: TextView? = null
    private var workflowBox: LinearLayout? = null
    private var runTarget: TextView? = null
    private var statusView: TextView? = null
    private var logView: TextView? = null

    private var workflows: List<String> = emptyList()
    private var workflowNote = "Belum dimuat."
    private var selectedWorkflow: String = api.prefs.getString(PREF_SELECTED, "").orEmpty()
    private var runUrl: String = ""
    private val logLines = mutableListOf<String>()

    // ---------------------------------------------------------------- util

    private fun dp(value: Int): Int = host.dp(value)

    /** Memakai repo yang sudah didaftarkan di aplikasi bila ada, jika tidak akun bawaan. */
    private fun owner(): String =
        api.customRepos().firstOrNull { it.repo.equals(REPO, ignoreCase = true) }?.owner ?: DEFAULT_OWNER

    /** Token khusus Lawn bila diisi, jika tidak token dari tab Akun. */
    private fun token(): String = api.readSecret(TOKEN_KEY).ifBlank { api.token() }

    private fun call(path: String, method: String = "GET", body: JSONObject? = null): String =
        api.request(path, method, body, token())

    private fun toast(text: String) = Toast.makeText(host, text, Toast.LENGTH_LONG).show()

    private fun setBusy(value: Boolean) {
        busy = value
        actionButtons.forEach { it.alpha = if (value) 0.5f else 1f }
    }

    private fun setStatus(text: String) { main.post { statusView?.text = text } }

    private fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        main.post {
            logLines.add("$time  $message")
            while (logLines.size > 10) logLines.removeAt(0)
            logView?.text = logLines.joinToString("\n")
        }
    }

    private fun hint(e: Exception): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("workflow", true) && m.contains("scope", true) ->
                "\n→ Token perlu izin Workflows (fine-grained) atau scope workflow (classic)."
            m.contains("API 401") || m.contains("API 403") ->
                "\n→ Cek izin token: Contents write, Actions write, Workflows write."
            m.contains("API 404") ->
                "\n→ Repo/workflow tidak ditemukan, atau token tidak punya akses ke repo $REPO."
            else -> ""
        }
    }

    private fun ready(): Boolean {
        if (busy) { toast("Masih ada proses berjalan"); return false }
        if (token().isBlank()) { toast("Isi token di tab Akun atau di kartu Token halaman ini"); return false }
        return true
    }

    // ---------------------------------------------------------------- tampilan

    private fun card(title: String, subtitle: String?): LinearLayout = LinearLayout(host).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = host.cardBackground()
        addView(host.sectionTitle(title, 15f))
        if (subtitle != null) {
            addView(host.label(subtitle, 12f, host.secondaryText()).apply { setPadding(0, dp(6), 0, dp(10)) })
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
    }

    private fun button(text: String, primary: Boolean, trackBusy: Boolean = true, onClick: () -> Unit): TextView =
        TextView(host).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (primary) host.onAccent() else host.primaryText())
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = host.pressable(if (primary) host.accentColor() else host.surfaceColor(), 14, !primary)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (trackBusy) actionButtons.add(this)
        }

    private fun LinearLayout.addSpaced(view: View, topDp: Int = 8) {
        addView(view, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) })
    }

    fun buildPage(): View {
        val scroll = ScrollView(host)
        val page = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        scroll.addView(page)

        page.addView(host.sectionTitle("Lawn Deploy", 22f))
        page.addView(host.label("${owner()}/$REPO · branch $BRANCH", 12f, host.secondaryText())
            .apply { setPadding(0, dp(4), 0, dp(16)) })

        // 1. Upload patch
        val patchCard = card("Upload patch", "Kirim file baru ke branch $BRANCH. File bernama sama akan diganti.")
        folderField = EditText(host).apply {
            hint = "Folder tujuan (kosong = root repo)"
            setSingleLine(true)
            host.styleField(this, true)
        }
        patchCard.addSpaced(folderField!!, 0)
        patchCard.addSpaced(button("Pilih file & upload", true) { if (ready()) host.launchLawnPatchPicker() })
        page.addView(patchCard)

        // 2. Workflow
        val wfCard = card("Workflow", "Isi $WORKFLOW_DIR/ di repo. Ketuk untuk memilih yang akan dijalankan.")
        workflowBox = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        wfCard.addSpaced(workflowBox!!, 0)
        wfCard.addSpaced(button("Upload / ganti file .yml", false) { if (ready()) host.launchLawnYmlPicker() })
        wfCard.addSpaced(button("Muat ulang daftar", false) { refreshWorkflows() })
        runTarget = host.label("", 12f, host.secondaryText()).apply { setPadding(0, dp(14), 0, 0) }
        wfCard.addView(runTarget)
        wfCard.addSpaced(button("▶  Run workflow", true) { runWorkflow() }, 6)
        page.addView(wfCard)

        // 3. Aktivitas
        val activity = card("Aktivitas", null)
        statusView = host.label("Siap.", 13f, host.accentColor(), true).apply {
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener { if (runUrl.isNotBlank()) openUrl(runUrl) }
        }
        activity.addView(statusView)
        logView = host.label("", 11f, host.secondaryText())
        activity.addView(logView)
        page.addView(activity)

        // 4. Token
        val tokenCard = card(
            "Token (opsional)",
            "Kosong = memakai token dari tab Akun. Untuk halaman ini token perlu izin Contents (write), " +
                "Actions (write), dan Workflows (write). Classic: scope repo + workflow."
        )
        tokenStatus = host.label("", 12f, host.primaryText(), true)
        tokenCard.addView(tokenStatus)
        tokenField = EditText(host).apply {
            hint = "Token baru (ghp_… / github_pat_…)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            host.styleField(this, true)
        }
        tokenCard.addSpaced(tokenField!!, 10)
        tokenCard.addSpaced(button("Simpan token", false, false) { saveToken() })
        tokenCard.addSpaced(button("Hapus token khusus", false, false) { clearToken() })
        page.addView(tokenCard)

        renderWorkflows()
        updateTokenStatus()
        return scroll
    }

    fun onShown() {
        updateTokenStatus()
        if (workflows.isEmpty() && token().isNotBlank()) refreshWorkflows()
    }

    private fun updateTokenStatus() {
        tokenStatus?.text =
            if (api.readSecret(TOKEN_KEY).isNotBlank()) "Token khusus Lawn tersimpan" else "Memakai token dari tab Akun"
    }

    private fun saveToken() {
        val value = tokenField?.text?.toString()?.trim().orEmpty()
        if (value.isBlank()) { toast("Token masih kosong"); return }
        try {
            api.saveSecret(TOKEN_KEY, value)
            tokenField?.setText("")
            updateTokenStatus()
            toast("Token Lawn tersimpan")
            refreshWorkflows()
        } catch (e: Exception) {
            toast("Gagal menyimpan token: ${e.message}")
        }
    }

    private fun clearToken() {
        api.saveSecret(TOKEN_KEY, "")
        updateTokenStatus()
        toast("Token khusus dihapus. Kembali memakai token Akun")
    }

    private fun renderWorkflows() {
        val box = workflowBox ?: return
        box.removeAllViews()
        if (workflows.isEmpty()) {
            box.addView(host.label(workflowNote, 12f, host.secondaryText()))
        }
        workflows.forEach { name ->
            val selected = name == selectedWorkflow
            val row = TextView(host).apply {
                text = (if (selected) "●  " else "○  ") + name
                textSize = 14f
                setTextColor(if (selected) host.accentColor() else host.primaryText())
                if (selected) setTypeface(null, Typeface.BOLD)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = host.pressable(host.surfaceColor(), 12, true)
                isClickable = true
                setOnClickListener { selectWorkflow(name) }
            }
            box.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6) })
        }
        runTarget?.text = if (selectedWorkflow.isBlank()) "Belum ada workflow dipilih" else "Akan dijalankan: $selectedWorkflow"
    }

    private fun selectWorkflow(name: String) {
        selectedWorkflow = name
        api.prefs.edit().putString(PREF_SELECTED, name).apply()
        renderWorkflows()
    }

    private fun openUrl(url: String) {
        try { host.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- daftar workflow

    private fun refreshWorkflows() {
        if (token().isBlank()) {
            workflows = emptyList()
            workflowNote = "Token belum diisi."
            renderWorkflows()
            return
        }
        executor.execute {
            try {
                val arr = JSONArray(call("/repos/${owner()}/$REPO/contents/$WORKFLOW_DIR?ref=$BRANCH"))
                val names = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val n = o.optString("name")
                    if (o.optString("type") == "file" && (n.endsWith(".yml") || n.endsWith(".yaml"))) names.add(n)
                }
                main.post {
                    workflows = names
                    workflowNote = "Belum ada file .yml di $WORKFLOW_DIR/."
                    if (selectedWorkflow !in names) selectedWorkflow = names.firstOrNull().orEmpty()
                    api.prefs.edit().putString(PREF_SELECTED, selectedWorkflow).apply()
                    renderWorkflows()
                }
            } catch (e: Exception) {
                val notFound = e.message?.contains("API 404") == true
                main.post {
                    workflows = emptyList()
                    workflowNote = if (notFound) "Folder $WORKFLOW_DIR/ belum ada di repo." else "Gagal memuat: ${e.message}"
                    renderWorkflows()
                }
                if (!notFound) log("✗ Muat workflow: ${e.message}${hint(e)}")
            }
        }
    }

    // ---------------------------------------------------------------- upload

    fun onPatchPicked(uris: List<Uri>) {
        if (!ready()) return
        val folder = folderField?.text?.toString().orEmpty().trim().replace('\\', '/').trim('/')
        if (folder.split('/').any { it == ".." || it == "." }) { toast("Folder tidak valid"); return }
        val items = uris.map { uri ->
            val name = host.queryDisplayName(uri)
            Pair(uri, if (folder.isBlank()) name else "$folder/$name")
        }
        val list = items.joinToString("\n") { "• ${it.second}" }
        confirm(
            "Upload ke $REPO/$BRANCH",
            "${items.size} file:\n$list\n\nFile dengan nama sama akan diganti.",
            "Upload"
        ) { uploadBatch(items, "Upload %s via RepoDeck") { if (it > 0) log("Selesai: $it/${items.size} file di-upload") } }
    }

    fun onYmlPicked(uri: Uri) {
        if (!ready()) return
        val name = host.queryDisplayName(uri)
        if (!(name.endsWith(".yml") || name.endsWith(".yaml"))) { toast("Pilih file .yml / .yaml"); return }
        val text = try {
            host.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
        } catch (_: Exception) { "" }
        val warn = if (text.contains("workflow_dispatch")) "" else
            "\n\nPeringatan: file ini tidak memuat workflow_dispatch, jadi tombol Run tidak akan bisa menjalankannya."

        fun go(targetName: String) {
            val path = "$WORKFLOW_DIR/$targetName"
            uploadBatch(listOf(Pair(uri, path)), "Update %s via RepoDeck") { ok ->
                if (ok > 0) {
                    main.post {
                        selectedWorkflow = targetName
                        api.prefs.edit().putString(PREF_SELECTED, targetName).apply()
                    }
                    refreshWorkflows()
                }
            }
        }

        val current = selectedWorkflow
        val builder = AlertDialog.Builder(host)
            .setTitle("Ganti workflow")
            .setNegativeButton("Batal", null)
        if (current.isNotBlank() && current != name) {
            builder.setMessage("Simpan sebagai $name, atau timpa $current dengan isi file ini?$warn")
                .setPositiveButton("Timpa $current") { _, _ -> go(current) }
                .setNeutralButton("Nama asli") { _, _ -> go(name) }
        } else {
            val exists = if (name in workflows) "akan diganti" else "file baru"
            builder.setMessage("$WORKFLOW_DIR/$name ($exists) di branch $BRANCH.$warn")
                .setPositiveButton("Upload") { _, _ -> go(name) }
        }
        host.showStyledDialog(builder.create())
    }

    private fun confirm(title: String, message: String, positive: String, onYes: () -> Unit) {
        host.showStyledDialog(
            AlertDialog.Builder(host)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(positive) { _, _ -> onYes() }
                .setNegativeButton("Batal", null)
                .create()
        )
    }

    /** [commitTemplate] memakai %s untuk path file. [onDone] menerima jumlah file yang berhasil. */
    private fun uploadBatch(items: List<Pair<Uri, String>>, commitTemplate: String, onDone: (Int) -> Unit) {
        setBusy(true)
        executor.execute {
            var ok = 0
            try {
                items.forEachIndexed { index, (uri, path) ->
                    setStatus("(${index + 1}/${items.size}) $path")
                    uploadOne(uri, path, commitTemplate.format(path))
                    ok++
                    log("✓ $path")
                }
                setStatus("Upload selesai ($ok file)")
            } catch (e: Exception) {
                log("✗ ${e.message}${hint(e)}")
                setStatus("Upload gagal")
            }
            main.post { setBusy(false); onDone(ok) }
        }
    }

    private fun uploadOne(uri: Uri, repoPath: String, message: String) {
        val bytes = host.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("File tidak dapat dibaca: $repoPath")
        if (bytes.size > MAX_BYTES) throw IllegalArgumentException("$repoPath terlalu besar (batas 50 MB)")
        val apiPath = "/repos/${owner()}/$REPO/contents/${Uri.encode(repoPath, "/")}"
        val existingSha = try {
            JSONObject(call("$apiPath?ref=$BRANCH")).optString("sha")
        } catch (e: Exception) {
            if (e.message?.contains("API 404") == true) "" else throw e
        }
        val body = JSONObject().put("message", message).put("branch", BRANCH)
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
        if (existingSha.isNotBlank()) body.put("sha", existingSha)
        val data = body.toString().toByteArray(Charsets.UTF_8)
        var last = -1
        api.requestWithProgress(apiPath, data, token()) { percent, _, _ ->
            if (percent != last) { last = percent; setStatus("Mengunggah $repoPath · $percent%") }
        }
    }

    // ---------------------------------------------------------------- run workflow

    private fun runWorkflow() {
        if (!ready()) return
        val wf = selectedWorkflow
        if (wf.isBlank()) { toast("Pilih workflow dulu"); return }
        setBusy(true)
        setStatus("Menjalankan $wf…")
        runUrl = ""
        val since = System.currentTimeMillis() - 15_000L
        executor.execute {
            try {
                call(
                    "/repos/${owner()}/$REPO/actions/workflows/${Uri.encode(wf)}/dispatches",
                    "POST", JSONObject().put("ref", BRANCH)
                )
                log("▶ $wf dijalankan di $BRANCH")
                main.post { setBusy(false); setStatus("Menunggu run muncul…"); pollRun(wf, since, 0) }
            } catch (e: Exception) {
                val extra = if (e.message?.contains("workflow_dispatch") == true)
                    "\n→ Tambahkan 'on: workflow_dispatch:' ke file yml." else hint(e)
                log("✗ Run gagal: ${e.message}$extra")
                main.post { setBusy(false); setStatus("Gagal menjalankan") }
            }
        }
    }

    private fun pollRun(workflow: String, since: Long, attempt: Int) {
        if (attempt > 72) { setStatus("Pemantauan berhenti. Cek tab Build."); return }
        main.postDelayed({
            executor.execute {
                var done = false
                try {
                    val runs = JSONObject(
                        call("/repos/${owner()}/$REPO/actions/runs?event=workflow_dispatch&branch=$BRANCH&per_page=5")
                    ).optJSONArray("workflow_runs") ?: JSONArray()
                    for (i in 0 until runs.length()) {
                        val r = runs.optJSONObject(i) ?: continue
                        val created = try { Instant.parse(r.optString("created_at")).toEpochMilli() } catch (_: Exception) { 0L }
                        if (created >= since && r.optString("path").contains(workflow)) {
                            val status = r.optString("status")
                            val conclusion = r.optString("conclusion")
                            runUrl = r.optString("html_url")
                            setStatus(describeRun(status, conclusion))
                            if (status == "completed") {
                                done = true
                                log("■ $workflow: ${describeRun(status, conclusion)}")
                            }
                            break
                        }
                    }
                } catch (_: Exception) {
                }
                if (!done) main.post { pollRun(workflow, since, attempt + 1) }
            }
        }, if (attempt == 0) 3000L else 5000L)
    }

    private fun describeRun(status: String, conclusion: String): String = when (status) {
        "queued", "waiting", "pending", "requested" -> "Antre di GitHub Actions…"
        "in_progress" -> "Sedang berjalan… (ketuk untuk buka di GitHub)"
        "completed" -> when (conclusion) {
            "success" -> "Selesai ✓ berhasil (ketuk untuk buka)"
            "failure" -> "Selesai ✗ gagal (ketuk untuk buka)"
            "cancelled" -> "Dibatalkan"
            else -> "Selesai: $conclusion"
        }
        else -> status
    }
}
