package com.repodeck.app

import android.content.Context
import android.os.Handler
import android.widget.Toast
import org.json.JSONArray
import java.io.File
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Logika pemantauan build GitHub yang tidak bergantung pada UI: polling berkala untuk ketiga
 * repository, pencocokan commit hasil upload ke workflow run, download otomatis
 * artifact/log, serta pencatatan hasil build. Berjalan selama aplikasi hidup, baik halaman
 * GitHub Manager terbuka maupun tidak.
 */
class GithubBuildMonitor(
    context: Context,
    private val api: GithubApi,
    private val executor: ExecutorService,
    private val mainHandler: Handler
) {
    /** Callback ke UI. Semuanya dipanggil di main thread. */
    interface Listener {
        fun isPageVisible(): Boolean
        fun selectedRepoSlug(): String
        /** Halaman GitHub sedang terbuka: segarkan repo yang dipilih secara diam-diam. */
        fun onTick()
        fun onRunCompleted(repoSlug: String, runId: Long, runName: String, conclusion: String)
        fun onRateLimited(untilMs: Long, message: String)
        /** Data run suatu repository (diambil di latar belakang) sudah diperbarui. */
        fun onRunsUpdated(repoSlug: String)
    }

    class RunResult(val runId: Long, val conclusion: String, val finishedAt: Long, val name: String)

    var listener: Listener? = null

    /** Run terbaru per repository (slug), diisi setiap kali daftar run diambil. */
    val runsCache = ConcurrentHashMap<String, JSONArray>()

    private val appContext: Context = context.applicationContext
    private val prefs get() = api.prefs

    private var polling = false
    private var scheduled = false
    private var serviceOn = false
    private var serviceStartedAt = 0L
    /** false saat aplikasi tidak terlihat; tanpa build pending polling dihentikan total. */
    @Volatile private var foreground = true
    /** Kapan sebuah repository mulai terdeteksi pending (untuk interval polling bertahap). */
    private val pendingSince = ConcurrentHashMap<String, Long>()
    private var lastReportedLimit = 0L
    private val bgInFlight = AtomicBoolean(false)
    private val lastPollAt = ConcurrentHashMap<String, Long>()

    private val pollRunnable = object : Runnable {
        override fun run() {
            scheduled = false
            if (!polling) return
            try {
                // Build yang sedang dipantau tetap diproses walau aplikasi di background; tanpa
                // build pending, polling hanya berjalan saat aplikasi terlihat.
                if (api.hasCredentials() && !api.isRateLimited()) {
                    val l = listener
                    val visible = foreground && l?.isPageVisible() == true
                    if (visible) l?.onTick()
                    pollReposInBackground(if (visible) (l?.selectedRepoSlug() ?: "") else "")
                }
                syncService(hasPending() && api.option("opt_background_monitor"))
            } catch (e: Exception) {
                CrashLogger.record(appContext, e, "poll tick")
            }
            scheduleNext()
        }
    }

    private fun scheduleNext() {
        if (!polling || scheduled) return
        if (!foreground && !hasPending()) return // jeda; dilanjutkan oleh setForeground/start
        scheduled = true
        mainHandler.postDelayed(pollRunnable, 3000L)
    }

    fun start() {
        polling = true
        // Bangunkan loop bila sedang dijeda (mis. setelah upload saat aplikasi di background).
        mainHandler.removeCallbacks(pollRunnable)
        scheduled = true
        mainHandler.post(pollRunnable)
    }

    /** Dipanggil dari onStart/onStop Activity. */
    fun setForeground(value: Boolean) {
        foreground = value
        if (value && polling) {
            mainHandler.removeCallbacks(pollRunnable)
            scheduled = true
            mainHandler.post(pollRunnable)
        }
    }

    fun stop() {
        polling = false
        scheduled = false
        mainHandler.removeCallbacks(pollRunnable)
        try { BuildMonitorService.stop(appContext) } catch (e: Exception) { }
        serviceOn = false
    }

    /** Semua callback ke main thread dibungkus agar error di dalamnya tidak mematikan aplikasi. */
    private fun safePost(block: () -> Unit) {
        mainHandler.post {
            try { block() } catch (e: Exception) { CrashLogger.record(appContext, e, "GithubBuildMonitor") }
        }
    }

    // ---------------------------------------------------------------- pending

    fun repoHasPending(slug: String): Boolean =
        prefs.getString("github_auto_build_commit_$slug", "").orEmpty().isNotBlank() ||
            prefs.getLong("github_auto_build_run_$slug", 0L) > 0L ||
            prefs.getStringSet("github_pending_$slug", emptySet()).orEmpty().isNotEmpty()

    // ---------------------------------------------------------------- APK hasil build

    private fun apkKey(repoSlug: String, runId: Long) = "github_apk_${repoSlug}_$runId"

    /** APK hasil ekstraksi untuk satu run (null bila belum ada atau file sudah terhapus). */
    fun apkFor(repoSlug: String, runId: Long): File? {
        val path = prefs.getString(apkKey(repoSlug, runId), null) ?: return null
        return File(path).takeIf { it.exists() }
    }

    private fun rememberApk(repoSlug: String, runId: Long, apk: File?) {
        if (apk != null) prefs.edit().putString(apkKey(repoSlug, runId), apk.absolutePath).apply()
    }

    fun hasPending(): Boolean = api.repositories.any { repoHasPending(api.repositorySlug(it)) }

    /** Menjaga proses tetap hidup (foreground service) hanya selama ada build yang dipantau. */
    private fun syncService(pending: Boolean) {
        // Android 15: service dataSync dibatasi waktunya dan dihentikan sistem (onTimeout).
        if (serviceOn && BuildMonitorService.lastTimeoutAt >= serviceStartedAt) serviceOn = false
        if (pending == serviceOn) return
        if (pending && System.currentTimeMillis() - BuildMonitorService.lastTimeoutAt < SERVICE_RETRY_AFTER_TIMEOUT_MS) return
        try {
            if (pending) {
                serviceStartedAt = System.currentTimeMillis()
                BuildMonitorService.start(appContext)
            } else {
                BuildMonitorService.stop(appContext)
            }
            serviceOn = pending
        } catch (e: Exception) {
            // Dicoba lagi pada tick berikutnya (mis. start ditolak saat aplikasi di background).
        }
    }

    /** Dipanggil setelah ZIP berhasil di-upload: mulai melacak commit-nya. */
    fun trackUploadedCommit(repoSlug: String, commitSha: String) {
        // Simpan juga ke daftar commit milik aplikasi (maks. 20 terakhir) supaya hanya run dari
        // upload RepoDeck yang diunduh otomatis; run dari push di luar aplikasi diabaikan.
        val appKey = appCommitsKey(repoSlug)
        val appCommits = (prefs.getString(appKey, "").orEmpty().split(',').filter { it.isNotBlank() } + commitSha.lowercase()).distinct().takeLast(20)
        prefs.edit().putString(appKey, appCommits.joinToString(","))
            .apply()
        prefs.edit()
            .putString("github_auto_build_commit_$repoSlug", commitSha)
            .putLong("github_auto_build_commit_time_$repoSlug", System.currentTimeMillis())
            .putLong("github_auto_build_run_$repoSlug", 0L)
            .remove(resultKey(repoSlug))
            .apply()
        lastPollAt.remove(repoSlug)
        pendingSince.remove(repoSlug)
    }

    private fun appCommitsKey(repoSlug: String) = "github_app_commits_$repoSlug"

    private fun appCommits(repoSlug: String): Set<String> =
        prefs.getString(appCommitsKey(repoSlug), "").orEmpty().split(',').filter { it.isNotBlank() }.toSet()

    // ---------------------------------------------------------------- dismiss kartu progress

    fun progressDismissKey(repoSlug: String, runId: Long): String = "github_progress_dismissed_${repoSlug}_$runId"

    fun isProgressDismissed(repoSlug: String, runId: Long): Boolean =
        prefs.getBoolean(progressDismissKey(repoSlug, runId), false)

    fun pendingProgressDismissKey(repoSlug: String): String = "github_progress_dismissed_pending_$repoSlug"

    fun transferPendingProgressDismiss(repoSlug: String, runId: Long) {
        if (prefs.getBoolean(pendingProgressDismissKey(repoSlug), false)) {
            prefs.edit()
                .putBoolean(progressDismissKey(repoSlug, runId), true)
                .remove(pendingProgressDismissKey(repoSlug))
                .apply()
        }
    }

    fun markProgressDismissed(repoSlug: String, runId: Long) {
        val key = if (runId > 0L) progressDismissKey(repoSlug, runId) else pendingProgressDismissKey(repoSlug)
        prefs.edit().putBoolean(key, true).commit()
    }

    // ---------------------------------------------------------------- hasil build

    private fun resultKey(repoSlug: String) = "github_last_result_$repoSlug"

    /** Hasil build terakhir (maks. 6 jam) untuk ditampilkan sebagai kartu hasil. */
    fun lastResult(repoSlug: String): RunResult? {
        val raw = prefs.getString(resultKey(repoSlug), null) ?: return null
        val parts = raw.split("|", limit = 4)
        if (parts.size < 4) return null
        val id = parts[0].toLongOrNull() ?: return null
        val at = parts[2].toLongOrNull() ?: return null
        if (System.currentTimeMillis() - at > RESULT_TTL_MS) return null
        return RunResult(id, parts[1], at, parts[3])
    }

    /** [note] != null: kirim notifikasi teks (untuk hasil yang tidak menghasilkan file unduhan). */
    private fun finishRun(repoSlug: String, run: JSONObject, conclusion: String, note: String?) {
        val id = run.optLong("id")
        val name = run.optString("name", "Workflow")
        prefs.edit().putString(resultKey(repoSlug), "$id|$conclusion|${System.currentTimeMillis()}|${name.replace('|', ' ')}").apply()
        safePost {
            if (note != null) {
                NotificationHelper.createChannel(appContext)
                NotificationHelper.show(
                    appContext, ("runresult_" + id).hashCode(),
                    "${api.displayNameForSlug(repoSlug)} · ${resultTitle(conclusion)}", note
                )
            }
            listener?.onRunCompleted(repoSlug, id, name, conclusion)
        }
    }

    // ---------------------------------------------------------------- error / rate limit

    /** Melaporkan rate limit ke UI (sekali per jendela pembatasan). */
    fun reportError(e: Exception) {
        if (e !is GithubRateLimitException) return
        if (e.untilMs == lastReportedLimit) return
        lastReportedLimit = e.untilMs
        val message = e.message ?: api.rateLimitMessage(e.untilMs)
        safePost { listener?.onRateLimited(e.untilMs, message) }
    }

    // ---------------------------------------------------------------- polling latar belakang

    /**
     * Memeriksa repository tanpa membutuhkan halamannya. Repository dengan build tertunda
     * dicek tiap ±3 detik, lainnya tiap 15 detik (4x lebih jarang bila kuota API menipis).
     * [skipSlug] = repository yang sudah disegarkan oleh halaman yang terlihat.
     */
    private fun pollReposInBackground(skipSlug: String) {
        val now = System.currentTimeMillis()
        val factor = if (api.rateLimitRemaining in 0..200) 4L else 1L
        val due = api.repositories.map { api.repositorySlug(it) }.filter { slug ->
            if (slug == skipSlug) return@filter false
            val pending = repoHasPending(slug)
            if (!pending) pendingSince.remove(slug)
            if (!pending && !foreground) return@filter false
            val interval = if (pending) {
                // Makin lama build berjalan, makin jarang dicek: 2,5 dtk -> 10 dtk -> 30 dtk.
                val elapsed = now - pendingSince.getOrPut(slug) { now }
                when {
                    elapsed < 60_000L -> 2500L
                    elapsed < 300_000L -> 10_000L
                    else -> 30_000L
                }
            } else 15_000L
            now - (lastPollAt[slug] ?: 0L) >= interval * factor
        }
        if (due.isEmpty()) return
        if (!bgInFlight.compareAndSet(false, true)) return
        due.forEach { lastPollAt[it] = now }
        try {
            executor.execute {
                try {
                    for (slug in due) {
                        try {
                            val runs = JSONObject(api.request("/repos/${api.ownerFor(slug)}/$slug/actions/runs?per_page=20"))
                                .optJSONArray("workflow_runs") ?: JSONArray()
                            handleRuns(slug, runs)
                            safePost { listener?.onRunsUpdated(slug) }
                        } catch (e: GithubRateLimitException) {
                            reportError(e)
                            break
                        } catch (e: Exception) {
                            // Abaikan; tick berikutnya mencoba lagi.
                        }
                    }
                } finally {
                    bgInFlight.set(false)
                }
            }
        } catch (e: RejectedExecutionException) {
            bgInFlight.set(false)
        }
    }

    /** Dipakai juga oleh halaman GitHub saat memuat daftar run. Harus dipanggil di executor. */
    fun handleRuns(repoSlug: String, runs: JSONArray) {
        runsCache[repoSlug] = runs
        resolveUploadedBuildRun(repoSlug, runs)
        processNewRuns(repoSlug, runs)
    }

    /** Mengaitkan commit hasil upload ZIP dengan workflow run-nya. Tidak menyentuh UI. */
    fun resolveUploadedBuildRun(repoSlug: String, runs: JSONArray) {
        val runKey = "github_auto_build_run_$repoSlug"
        if (prefs.getLong(runKey, 0L) > 0L) return
        val commitKey = "github_auto_build_commit_$repoSlug"
        val timeKey = "github_auto_build_commit_time_$repoSlug"
        val commitSha = prefs.getString(commitKey, "").orEmpty()
        if (commitSha.isBlank()) return
        val matched = (0 until runs.length()).map { runs.optJSONObject(it) }.firstOrNull {
            it != null && it.optString("head_sha").equals(commitSha, ignoreCase = true)
        }
        val runId = matched?.optLong("id") ?: 0L
        if (runId <= 0L) {
            // Tidak ada run (mis. workflow tanpa trigger push): berhenti menunggu setelah 3 menit.
            val since = prefs.getLong(timeKey, 0L)
            if (since > 0L && System.currentTimeMillis() - since > 180_000L) {
                prefs.edit().remove(commitKey).remove(timeKey).apply()
            }
            return
        }
        transferPendingProgressDismiss(repoSlug, runId)
        prefs.edit().putLong(runKey, runId).remove(commitKey).remove(timeKey).apply()
    }

    private fun processNewRuns(repoSlug: String, runs: JSONArray) {
        if (runs.length() == 0) return
        val key = "github_last_seen_$repoSlug"
        val newestId = runs.optJSONObject(0)?.optLong("id") ?: return
        val hasBaseline = prefs.contains(key)
        val lastSeen = prefs.getLong(key, newestId)
        val pendingKey = "github_pending_$repoSlug"
        val pending = prefs.getStringSet(pendingKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        // Selalu sertakan run milik upload ZIP terakhir, walau baseline belum terbentuk.
        val uploadedRunId = prefs.getLong("github_auto_build_run_$repoSlug", 0L)
        if (uploadedRunId > 0L && (0 until runs.length()).any { runs.optJSONObject(it)?.optLong("id") == uploadedRunId }) {
            pending.add(uploadedRunId.toString())
        }
        if (!hasBaseline) {
            prefs.edit().putLong(key, newestId).putStringSet(pendingKey, pending.toSet()).apply()
            // Tetap proses run upload yang dilacak secara eksplisit.
            if (pending.isEmpty()) return
        }
        // Hanya run yang berasal dari commit upload RepoDeck yang diunduh otomatis. Run baru dari
        // push di luar aplikasi (git, web GitHub, dsb.) cukup menggeser baseline "last seen".
        val ownCommits = appCommits(repoSlug)
        for (i in 0 until runs.length()) {
            val run = runs.getJSONObject(i)
            val id = run.optLong("id")
            if (hasBaseline && id > lastSeen && run.optString("head_sha").lowercase() in ownCommits) {
                pending.add(id.toString())
            }
        }
        if (newestId > lastSeen) prefs.edit().putLong(key, newestId).apply()
        val runById = (0 until runs.length()).map { runs.getJSONObject(it) }.associateBy { it.optLong("id").toString() }
        // Run pending yang sudah lebih lama dari run tertua di daftar (20 terbaru) tidak akan
        // muncul lagi; buang supaya repository tidak dianggap pending selamanya.
        val oldestId = (0 until runs.length()).minOf { runs.getJSONObject(it).optLong("id") }
        val stale = pending.filter { (it.toLongOrNull() ?: 0L) < oldestId && it !in runById }
        if (stale.isNotEmpty()) {
            pending.removeAll(stale.toSet())
            val runKey = "github_auto_build_run_$repoSlug"
            if (stale.any { it.toLongOrNull() == prefs.getLong(runKey, 0L) }) prefs.edit().putLong(runKey, 0L).apply()
        }
        for (idText in pending.toList()) {
            val run = runById[idText] ?: continue
            if (run.optString("status") != "completed") continue
            if (!handleCompletedRun(repoSlug, run, idText, pending)) break
        }
        prefs.edit().putStringSet(pendingKey, pending.toSet()).apply()
    }

    /** @return false bila pemrosesan harus berhenti sementara (terkena rate limit). */
    private fun handleCompletedRun(repoSlug: String, run: JSONObject, idText: String, pending: MutableSet<String>): Boolean {
        val id = run.optLong("id")
        val conclusion = run.optString("conclusion")
        val owner = api.ownerFor(repoSlug)
        val runKey = "github_auto_build_run_$repoSlug"
        val errKey = "github_run_errors_${repoSlug}_$id"
        fun clearTracking() {
            pending.remove(idText)
            if (prefs.getLong(runKey, 0L) == id) prefs.edit().putLong(runKey, 0L).apply()
        }
        try {
            if (!api.option("opt_auto_download") && (conclusion == "success" || conclusion == "failure")) {
                clearTracking()
                finishRun(repoSlug, run, conclusion, "Build selesai. Unduh manual dari tab Build.")
                prefs.edit().remove(errKey).apply()
                return true
            }
            if (conclusion == "success") {
                val artifacts = JSONObject(api.request("/repos/$owner/$repoSlug/actions/runs/$id/artifacts?per_page=100"))
                    .optJSONArray("artifacts") ?: JSONArray()
                if (artifacts.length() == 0) {
                    // GitHub dapat menampilkan run selesai sebelum artifact-nya terindeks.
                    val retryKey = "github_artifact_index_retries_${repoSlug}_$id"
                    val retries = prefs.getInt(retryKey, 0) + 1
                    if (retries >= 20) {
                        prefs.edit().remove(retryKey).apply()
                        clearTracking()
                        finishRun(repoSlug, run, conclusion, "Build selesai, tetapi workflow tidak menghasilkan artifact.")
                    } else {
                        prefs.edit().putInt(retryKey, retries).apply()
                    }
                    return true
                }
                prefs.edit().remove("github_artifact_index_retries_${repoSlug}_$id").apply()
                val doneKey = "github_artifacts_downloaded_$repoSlug"
                for (i in 0 until artifacts.length()) {
                    val artifact = artifacts.getJSONObject(i)
                    if (artifact.optBoolean("expired")) continue
                    val artifactId = artifact.optLong("id")
                    val downloaded = prefs.getStringSet(doneKey, emptySet())?.toMutableSet() ?: mutableSetOf()
                    if (artifactId.toString() in downloaded) continue
                    val artifactName = artifact.optString("name", "artifact-$artifactId")
                    val temp = api.downloadArchiveToCache("/repos/$owner/$repoSlug/actions/artifacts/$artifactId/zip", "artifact_${artifactId}.zip")
                    try {
                        val saved = api.saveDownload(temp, repoSlug, "Builds", "$artifactName.zip")
                        // Tandai langsung setelah tersimpan: kegagalan di langkah berikutnya
                        // (mis. ekstrak APK) tidak boleh membuat artifact yang sama tersimpan lagi.
                        downloaded.add(artifactId.toString())
                        prefs.edit().putStringSet(doneKey, downloaded).apply()
                        val apk = try { api.extractApk(temp, repoSlug) } catch (e: Exception) { null }
                        rememberApk(repoSlug, id, apk)
                        announceSavedFile(
                            repoSlug, saved, ("artifact_" + artifactId).hashCode(),
                            "Artifact tersimpan: ${saved.name}", "Build selesai diunduh", apk
                        )
                    } finally {
                        temp.delete()
                    }
                }
                clearTracking()
                finishRun(repoSlug, run, conclusion, null)
            } else if (conclusion == "failure") {
                val doneKey = "github_failure_logs_downloaded_$repoSlug"
                val downloaded = prefs.getStringSet(doneKey, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (id.toString() !in downloaded) {
                    val temp = api.downloadArchiveToCache("/repos/$owner/$repoSlug/actions/runs/$id/logs", "build_logs_$id.zip")
                    try {
                        if (api.zipEntryCount(temp) <= 0) {
                            // GitHub kadang mengirim arsip kosong sebelum log selesai disusun, atau
                            // memang kosong bila workflow gagal sebelum ada job yang berjalan.
                            val emptyKey = "github_empty_log_retries_${repoSlug}_$id"
                            val tries = prefs.getInt(emptyKey, 0) + 1
                            if (tries < 5) {
                                prefs.edit().putInt(emptyKey, tries).apply()
                                return true // coba lagi di tick berikutnya
                            }
                            prefs.edit().remove(emptyKey).remove(errKey).apply()
                            clearTracking()
                            finishRun(
                                repoSlug, run, conclusion,
                                "Build gagal, tetapi GitHub tidak menyediakan log (kemungkinan workflow gagal sebelum job berjalan). Periksa tab Actions di GitHub."
                            )
                            return true
                        }
                        val saved = api.saveDownload(temp, repoSlug, "BuildLogs", "build-$id.zip")
                        downloaded.add(id.toString())
                        prefs.edit().putStringSet(doneKey, downloaded).apply()
                        announceSavedFile(
                            repoSlug, saved, ("buildlog_" + id).hashCode(),
                            "Log build gagal tersimpan: ${saved.name}", "Log build berhasil diunduh"
                        )
                    } finally {
                        temp.delete()
                    }
                }
                clearTracking()
                finishRun(repoSlug, run, conclusion, null)
            } else {
                // cancelled, timed_out, skipped, dll.: tidak ada file, cukup beri tahu.
                clearTracking()
                finishRun(repoSlug, run, conclusion, conclusionNote(conclusion))
            }
            prefs.edit().remove(errKey).apply()
            return true
        } catch (e: GithubRateLimitException) {
            reportError(e)
            return false
        } catch (e: Exception) {
            // Archive/log bisa belum siap; coba lagi di tick berikutnya, menyerah setelah 20 kali.
            val errors = prefs.getInt(errKey, 0) + 1
            if (errors >= 20) {
                prefs.edit().remove(errKey).apply()
                clearTracking()
                finishRun(repoSlug, run, conclusion, "Gagal mengunduh hasil build: ${e.message}")
            } else {
                prefs.edit().putInt(errKey, errors).apply()
                if (listener?.isPageVisible() == true) {
                    safePost {
                        Toast.makeText(appContext, "Menunggu artifact/log tersedia: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            return true
        }
    }

    /** Unduh manual semua artifact milik satu run (tombol "Unduh" di daftar run). */
    fun downloadRunArtifacts(repoSlug: String, runId: Long, install: Boolean = false) {
        executor.execute {
            try {
                if (install) {
                    val existing = apkFor(repoSlug, runId)
                    if (existing != null) {
                        safePost { ApkInstaller.install(appContext, existing) }
                        return@execute
                    }
                }
                val owner = api.ownerFor(repoSlug)
                val artifacts = JSONObject(api.request("/repos/$owner/$repoSlug/actions/runs/$runId/artifacts?per_page=100"))
                    .optJSONArray("artifacts") ?: JSONArray()
                var count = 0
                var chosenApk: File? = null
                for (i in 0 until artifacts.length()) {
                    val artifact = artifacts.getJSONObject(i)
                    if (artifact.optBoolean("expired")) continue
                    val artifactId = artifact.optLong("id")
                    val artifactName = artifact.optString("name", "artifact-$artifactId")
                    val temp = api.downloadArchiveToCache("/repos/$owner/$repoSlug/actions/artifacts/$artifactId/zip", "artifact_${artifactId}.zip")
                    val saved = api.saveDownload(temp, repoSlug, "Builds", "$artifactName.zip")
                    val apk = api.extractApk(temp, repoSlug)
                    if (chosenApk == null) chosenApk = apk
                    temp.delete()
                    announceSavedFile(
                        repoSlug, saved, ("artifact_" + artifactId).hashCode(),
                        "Artifact tersimpan: ${saved.name}", "Artifact diunduh", apk
                    )
                    count++
                }
                rememberApk(repoSlug, runId, chosenApk)
                val apkToInstall = chosenApk
                if (install) {
                    if (apkToInstall != null) {
                        safePost { ApkInstaller.install(appContext, apkToInstall) }
                    } else {
                        safePost { Toast.makeText(appContext, "Artifact run ini tidak berisi APK.", Toast.LENGTH_LONG).show() }
                    }
                } else if (count == 0) {
                    safePost { Toast.makeText(appContext, "Tidak ada artifact yang dapat diunduh untuk run ini.", Toast.LENGTH_LONG).show() }
                }
            } catch (e: GithubRateLimitException) {
                reportError(e)
            } catch (e: Exception) {
                safePost { Toast.makeText(appContext, "Gagal mengunduh artifact: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun announceSavedFile(repoSlug: String, saved: SavedFile, notificationId: Int, toast: String, title: String, apk: File? = null) {
        val fileUri = saved.uri
        val apkUri = if (!api.option("opt_offer_install")) null else try { apk?.let { ApkInstaller.uriFor(appContext, it) } } catch (e: Exception) { null }
        safePost {
            Toast.makeText(appContext, toast, Toast.LENGTH_LONG).show()
            if (fileUri != null) {
                NotificationHelper.createChannel(appContext)
                NotificationHelper.showFile(
                    appContext, notificationId, title,
                    "${api.displayNameForSlug(repoSlug)} · ${saved.name}",
                    fileUri, api.fileMimeType(saved.name), apkUri
                )
            }
        }
    }

    companion object {
        private const val SERVICE_RETRY_AFTER_TIMEOUT_MS = 30L * 60L * 1000L
        private const val RESULT_TTL_MS = 6L * 60L * 60L * 1000L

        fun resultTitle(conclusion: String): String = when (conclusion) {
            "success" -> "Build berhasil"
            "failure" -> "Build gagal"
            "cancelled" -> "Build dibatalkan"
            "timed_out" -> "Build melewati batas waktu"
            else -> "Build selesai"
        }

        private fun conclusionNote(conclusion: String): String = when (conclusion) {
            "cancelled" -> "Build dibatalkan."
            "timed_out" -> "Build melewati batas waktu."
            "skipped" -> "Build dilewati."
            else -> "Build selesai dengan status: ${conclusion.ifBlank { "tidak diketahui" }}."
        }
    }
}
