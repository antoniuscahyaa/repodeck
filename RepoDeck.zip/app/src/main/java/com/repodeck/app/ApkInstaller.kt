package com.repodeck.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Membuka installer sistem untuk APK hasil build (APK diekstrak dari artifact oleh [GithubApi.extractApk]). */
object ApkInstaller {
    const val APK_MIME = "application/vnd.android.package-archive"

    fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context.applicationContext, "${context.packageName}.fileprovider", file)

    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

    private fun installIntent(context: Context, file: File): Intent {
        val uri = uriFor(context, file)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, APK_MIME)
            clipData = ClipData.newRawUri("APK", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Membuka installer. Bila izin "pasang aplikasi dari sumber ini" belum aktif untuk RepoDeck,
     * halaman pengaturannya dibuka lebih dulu; setelah diizinkan, ketuk Install lagi.
     */
    fun install(context: Context, file: File) {
        val app = context.applicationContext
        if (!file.exists()) {
            Toast.makeText(app, "File APK tidak ditemukan. Unduh ulang dari daftar run.", Toast.LENGTH_LONG).show()
            return
        }
        if (!canInstall(app)) {
            Toast.makeText(app, "Izinkan RepoDeck memasang aplikasi, lalu ketuk Install lagi.", Toast.LENGTH_LONG).show()
            try {
                app.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                Toast.makeText(app, "Buka Pengaturan > Aplikasi > RepoDeck > Pasang aplikasi tidak dikenal.", Toast.LENGTH_LONG).show()
            }
            return
        }
        try {
            app.startActivity(installIntent(app, file))
        } catch (e: Exception) {
            Toast.makeText(app, "Tidak dapat membuka installer: ${e.message ?: "kesalahan sistem"}", Toast.LENGTH_LONG).show()
        }
    }
}
