package com.repodeck.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.io.File

/**
 * Ikon aplikasi per repository untuk pill di tab Repo. Disimpan sebagai PNG 192px di
 * filesDir/repo_icons/<slug>.png. Sumber: pilihan manual dari galeri, atau diambil
 * otomatis dari mipmap launcher PNG di repo (ikon adaptive berbentuk XML tidak didukung;
 * untuk itu dipakai pilihan manual atau inisial).
 */
class RepoIcons(context: Context, private val api: GithubApi) {

    private val appContext = context.applicationContext
    private val dir = File(appContext.filesDir, "repo_icons").apply { mkdirs() }
    private val memory = HashMap<String, Bitmap>()

    private fun file(slug: String) = File(dir, "$slug.png")

    @Synchronized
    fun bitmap(slug: String): Bitmap? {
        memory[slug]?.let { return it }
        val f = file(slug)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        memory[slug] = bmp
        return bmp
    }

    fun has(slug: String): Boolean = file(slug).exists()

    @Synchronized
    fun remove(slug: String) {
        memory.remove(slug)
        file(slug).delete()
        // Tandai sudah dicoba agar ikon yang sengaja dihapus tidak diunduh ulang otomatis.
        api.prefs.edit().putBoolean(triedKey(slug), true).apply()
    }

    fun triedAuto(slug: String): Boolean = api.prefs.getBoolean(triedKey(slug), false)

    fun markTried(slug: String) { api.prefs.edit().putBoolean(triedKey(slug), true).apply() }

    fun resetTried(slug: String) { api.prefs.edit().remove(triedKey(slug)).apply() }

    private fun triedKey(slug: String) = "icon_tried_$slug"

    /** Menyimpan gambar pilihan pengguna. Jalankan di thread latar. */
    fun saveFromUri(slug: String, uri: Uri): Boolean = try {
        val resolver = appContext.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= SIZE && bounds.outHeight / (sample * 2) >= SIZE) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        decoded != null && store(slug, decoded)
    } catch (_: Exception) {
        false
    }

    /**
     * Mencari ic_launcher.png di repo. Mengembalikan true bila ikon tersimpan, false bila
     * repo memang tidak punya PNG; melempar exception bila jaringan/kuota gagal (jangan
     * ditandai sudah dicoba). Jalankan di thread latar.
     */
    fun fetchFromRepo(slug: String): Boolean {
        val owner = api.ownerFor(slug)
        val branch = api.branchFor(slug)
        for (density in listOf("xxxhdpi", "xxhdpi", "xhdpi")) {
            val path = "app/src/main/res/mipmap-$density/ic_launcher.png"
            val body = try {
                api.request("/repos/$owner/$slug/contents/$path?ref=$branch")
            } catch (e: IllegalStateException) {
                if (e.message?.startsWith("GitHub API 404") == true) continue
                throw e
            }
            val encoded = JSONObject(body).optString("content").replace("\n", "")
            if (encoded.isBlank()) continue
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
            if (store(slug, bmp)) return true
        }
        return false
    }

    @Synchronized
    private fun store(slug: String, source: Bitmap): Boolean = try {
        val side = minOf(source.width, source.height)
        val square = Bitmap.createBitmap(source, (source.width - side) / 2, (source.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, SIZE, SIZE, true)
        file(slug).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        memory[slug] = scaled
        true
    } catch (_: Exception) {
        false
    }

    companion object {
        private const val SIZE = 192

        /** "EnduranceVault" -> "EV", "Aplikasi Kasir" -> "AK", "dialchat" -> "DI". */
        fun initials(name: String): String {
            val words = name.split(' ', '-', '_', '.').filter { it.isNotBlank() }
            if (words.size >= 2) return "${words[0].first()}${words[1].first()}".uppercase()
            val word = words.firstOrNull().orEmpty()
            val caps = word.filter { it.isUpperCase() }
            return if (caps.length >= 2) caps.take(2) else word.take(2).uppercase()
        }
    }
}
