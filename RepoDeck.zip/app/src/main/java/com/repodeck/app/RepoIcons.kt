package com.repodeck.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.util.Base64
import android.util.Xml
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.PathParser
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.File
import java.io.StringReader
import java.util.zip.ZipInputStream

/**
 * Ikon aplikasi per repository untuk pill di tab Repo. Disimpan sebagai PNG 192px di
 * filesDir/repo_icons/<slug>.png. Sumber: pilihan manual dari galeri, atau diambil otomatis
 * dari repo (file langsung atau di dalam ZIP proyek di root): (1) ic_launcher.png/.webp atau
 * ic_launcher-playstore.png, (2) bila tidak ada, adaptive icon XML (background + vector
 * foreground) digambar sendiri. Bila semuanya gagal dipakai pilihan manual atau inisial.
 */
class RepoIcons(context: Context, private val api: GithubApi) {

    private val appContext = context.applicationContext
    private val dir = File(appContext.filesDir, "repo_icons").apply { mkdirs() }
    private val memory = HashMap<String, Bitmap>()

    private fun file(slug: String) = File(dir, "$slug.png")

    @Synchronized
    fun bitmap(slug: String): Bitmap? {
        memory[slug]?.let { return it }
        val f = file(slug)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        memory[slug] = bmp
        return bmp
    }

    fun has(slug: String): Boolean = file(slug).exists()

    @Synchronized
    fun remove(slug: String) {
        memory.remove(slug)
        file(slug).delete()
        // Tandai sudah dicoba agar ikon yang sengaja dihapus tidak diunduh ulang otomatis.
        api.prefs.edit().putBoolean(triedKey(slug), true).apply()
    }

    fun triedAuto(slug: String): Boolean = api.prefs.getBoolean(triedKey(slug), false)

    fun markTried(slug: String) { api.prefs.edit().putBoolean(triedKey(slug), true).apply() }

    fun resetTried(slug: String) { api.prefs.edit().remove(triedKey(slug)).apply() }

    private fun triedKey(slug: String) = "icon_tried2_$slug"

    /** Menyimpan gambar pilihan pengguna. Jalankan di thread latar. */
    fun saveFromUri(slug: String, uri: Uri): Boolean = try {
        val resolver = appContext.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= SIZE && bounds.outHeight / (sample * 2) >= SIZE) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        decoded != null && store(slug, decoded)
    } catch (_: Exception) {
        false
    }

    /**
     * Mencari ikon aplikasi di repo. Mengembalikan true bila ikon tersimpan, false bila repo
     * memang tidak punya ikon yang bisa dipakai; melempar exception bila jaringan/kuota gagal
     * (jangan ditandai sudah dicoba). Jalankan di thread latar.
     *
     * Dua susunan repo didukung: file proyek langsung di repo, atau repo yang hanya berisi ZIP
     * proyek di root (susunan upload dari RepoDeck): ZIP diunduh lalu dibaca di memori.
     */
    fun fetchFromRepo(slug: String): Boolean {
        val owner = api.ownerFor(slug)
        val branch = api.branchFor(slug)
        val nodes = listRepoFiles(owner, slug, branch)
            ?.filter { !it.path.contains("/build/") && !it.path.startsWith("build/") && !it.path.contains("androidTest") }
            ?: return false

        // 1. File proyek langsung di repo.
        val direct = RepoSource(owner, slug, branch, nodes.map { it.path })
        findIcon(direct)?.let { return store(slug, it) }

        // 2. Repo berisi ZIP proyek di root: baca ikon dari dalam ZIP.
        val zips = nodes
            .filter { !it.path.contains('/') && it.path.endsWith(".zip", ignoreCase = true) && it.size in 1..MAX_ZIP_BYTES }
            .sortedWith(compareByDescending<TreeNode> { it.path.contains(slug, ignoreCase = true) }.thenByDescending { it.size })
            .take(2)
        for (zip in zips) {
            val bytes = fetchBlob(owner, slug, zip.sha) ?: continue
            findIcon(ZipSource(readZipEntries(bytes)))?.let { return store(slug, it) }
        }
        return false
    }

    /** Ikon dari sumber file: raster (PNG/WebP/playstore) dahulu, lalu adaptive icon XML. */
    private fun findIcon(source: FileSource): Bitmap? {
        val files = source.paths
        val rasters = files.filter { rasterRegex.containsMatchIn(it) }.sortedByDescending { rasterScore(it) }.take(3)
        for (path in rasters) {
            val bytes = source.read(path) ?: continue
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
            return bmp
        }
        val xmlPath = files.filter { adaptiveRegex.matches(it) }
            .minWithOrNull(compareBy({ !it.startsWith("app/") }, { it.length })) ?: return null
        val resDir = adaptiveRegex.find(xmlPath)?.groupValues?.get(1) ?: return null
        val xml = source.read(xmlPath)?.toString(Charsets.UTF_8) ?: return null
        return Renderer(source, resDir).render(xml)
    }

    private class TreeNode(val path: String, val sha: String, val size: Long)

    private interface FileSource {
        val paths: Collection<String>
        fun read(path: String): ByteArray?
    }

    /** File langsung di repo, dibaca lewat Contents API. */
    private inner class RepoSource(
        val owner: String, val slug: String, val branch: String, override val paths: List<String>
    ) : FileSource {
        override fun read(path: String): ByteArray? = fetchBytes(owner, slug, branch, path)
    }

    /** File di dalam ZIP proyek yang sudah dimuat ke memori. */
    private class ZipSource(private val entries: Map<String, ByteArray>) : FileSource {
        override val paths: Collection<String> get() = entries.keys
        override fun read(path: String): ByteArray? = entries[path]
    }

    private val resFileRegex = Regex("(^|/)res/[^/]+/[^/]+\\.(xml|png|webp)\\z", RegexOption.IGNORE_CASE)

    /** Hanya menyimpan berkas yang berguna untuk ikon (res/*, ic_launcher*) agar hemat memori. */
    private fun readZipEntries(zip: ByteArray): Map<String, ByteArray> {
        val out = HashMap<String, ByteArray>()
        var total = 0L
        try {
            ZipInputStream(zip.inputStream()).use { zis ->
                var entry = zis.nextEntry
                var scanned = 0
                while (entry != null && scanned++ < 20_000) {
                    val name = entry.name.replace('\\', '/').trimStart('/')
                    val wanted = !entry.isDirectory && entry.size <= MAX_ENTRY_BYTES &&
                        !name.contains("/build/") && !name.startsWith("build/") && !name.contains("androidTest") &&
                        (resFileRegex.containsMatchIn(name) || rasterRegex.containsMatchIn(name))
                    if (wanted) {
                        val data = zis.readBytes()
                        total += data.size
                        if (data.size <= MAX_ENTRY_BYTES) out[name] = data
                        if (total > MAX_TOTAL_BYTES) break
                    }
                    entry = zis.nextEntry
                }
            }
        } catch (_: java.io.IOException) {
        }
        return out
    }

    private val rasterRegex = Regex("(^|/)ic_launcher(-playstore)?\\.(png|webp)\\z")
    private val adaptiveRegex = Regex("^((?:.*/)?res/)mipmap-anydpi(-v\\d+)?/ic_launcher\\.xml\\z")

    private fun rasterScore(path: String): Int = (when {
        path.contains("playstore") -> 100
        path.contains("-xxxhdpi") -> 60
        path.contains("-xxhdpi") -> 50
        path.contains("-xhdpi") -> 40
        path.contains("-hdpi") -> 30
        path.contains("-mdpi") -> 20
        else -> 10
    }) + (if (path.startsWith("app/")) 5 else 0)

    /** Daftar semua file di branch (satu request). Null bila repo kosong atau branch tidak ada. */
    private fun listRepoFiles(owner: String, slug: String, branch: String): List<TreeNode>? {
        val body = try {
            api.request("/repos/$owner/$slug/git/trees/${Uri.encode(branch)}?recursive=1")
        } catch (e: IllegalStateException) {
            val m = e.message.orEmpty()
            if (m.startsWith("GitHub API 404") || m.startsWith("GitHub API 409")) return null
            throw e
        }
        val tree = JSONObject(body).optJSONArray("tree") ?: return null
        val out = ArrayList<TreeNode>(tree.length())
        for (i in 0 until tree.length()) {
            val node = tree.optJSONObject(i) ?: continue
            if (node.optString("type") == "blob") {
                out.add(TreeNode(node.optString("path"), node.optString("sha"), node.optLong("size", -1L)))
            }
        }
        return out
    }

    /** Isi blob lewat Git Blobs API (tidak dibatasi 1 MB seperti Contents API). */
    private fun fetchBlob(owner: String, slug: String, sha: String): ByteArray? {
        val body = try {
            api.request("/repos/$owner/$slug/git/blobs/$sha")
        } catch (e: IllegalStateException) {
            if (e.message?.startsWith("GitHub API 404") == true) return null
            throw e
        }
        val json = JSONObject(body)
        if (json.optString("encoding") != "base64") return null
        val encoded = json.optString("content").replace("\n", "")
        if (encoded.isBlank()) return null
        return Base64.decode(encoded, Base64.DEFAULT)
    }

    /** Isi file (maks. 1 MB, batas Contents API). Null bila tidak ada atau terlalu besar. */
    private fun fetchBytes(owner: String, slug: String, branch: String, path: String): ByteArray? {
        val body = try {
            api.request("/repos/$owner/$slug/contents/${Uri.encode(path, "/")}?ref=${Uri.encode(branch)}")
        } catch (e: IllegalStateException) {
            if (e.message?.startsWith("GitHub API 404") == true) return null
            throw e
        }
        val encoded = JSONObject(body).optString("content").replace("\n", "")
        if (encoded.isBlank()) return null
        return Base64.decode(encoded, Base64.DEFAULT)
    }

    private fun attr(p: XmlPullParser, local: String): String? {
        for (i in 0 until p.attributeCount) {
            val n = p.getAttributeName(i)
            if (n == local || n.endsWith(":$local")) return p.getAttributeValue(i)
        }
        return null
    }

    /**
     * Menggambar adaptive icon dari sumbernya: background (warna/vector/gambar) + foreground
     * (vector/gambar) pada kanvas 108dp, lalu dipotong ke area tampil 72dp di tengah.
     * Mendukung <vector> dengan <group> (translate/rotate/scale) dan <path> (fill/stroke);
     * gradient dan clip-path diabaikan.
     */
    private inner class Renderer(private val source: FileSource, private val resDir: String) {
        private val paths: Collection<String> = source.paths
        private var colors: Map<String, String>? = null

        fun render(adaptiveXml: String): Bitmap? {
            var bgRef: String? = null
            var fgRef: String? = null
            var current: String? = null
            try {
                val p = Xml.newPullParser()
                p.setInput(StringReader(adaptiveXml))
                var event = p.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG) {
                        val ref = attr(p, "drawable") ?: attr(p, "color")
                        when (p.name) {
                            "background", "foreground" -> {
                                current = p.name
                                if (ref != null) { if (current == "background") bgRef = ref else fgRef = ref }
                            }
                            "inset", "color" -> if (ref != null) {
                                if (current == "background" && bgRef == null) bgRef = ref
                                if (current == "foreground" && fgRef == null) fgRef = ref
                            }
                        }
                    } else if (event == XmlPullParser.END_TAG && (p.name == "background" || p.name == "foreground")) {
                        current = null
                    }
                    event = p.next()
                }
            } catch (_: XmlPullParserException) {
                return null
            }
            val fg = fgRef ?: return null
            val full = Bitmap.createBitmap(FULL, FULL, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(full)
            bgRef?.let { drawLayer(canvas, it) }
            if (!drawLayer(canvas, fg)) return null // hanya latar polos tidak berguna: pakai inisial
            val margin = FULL / 6 // area tampil 72 dari 108
            return Bitmap.createBitmap(full, margin, margin, FULL - 2 * margin, FULL - 2 * margin)
        }

        private fun text(path: String): String? = source.read(path)?.toString(Charsets.UTF_8)

        private fun colorTable(): Map<String, String> {
            colors?.let { return it }
            val map = HashMap<String, String>()
            val file = resDir + "values/colors.xml"
            val xml = if (file in paths) text(file) else null
            if (xml != null) {
                try {
                    val p = Xml.newPullParser()
                    p.setInput(StringReader(xml))
                    var event = p.eventType
                    while (event != XmlPullParser.END_DOCUMENT) {
                        if (event == XmlPullParser.START_TAG && p.name == "color") {
                            val name = attr(p, "name")
                            val value = p.nextText().trim()
                            if (name != null) map[name] = value
                        }
                        event = p.next()
                    }
                } catch (_: XmlPullParserException) {
                }
            }
            colors = map
            return map
        }

        private fun colorOf(ref: String, depth: Int = 0): Int? {
            val v = ref.trim()
            if (v.startsWith("#")) return try { Color.parseColor(v) } catch (_: IllegalArgumentException) { null }
            if (depth > 4) return null
            return when {
                v.startsWith("@color/") -> {
                    val raw = colorTable()[v.removePrefix("@color/")] ?: return null
                    colorOf(raw, depth + 1)
                }
                v == "@android:color/white" -> Color.WHITE
                v == "@android:color/black" -> Color.BLACK
                v == "@android:color/transparent" -> Color.TRANSPARENT
                else -> null
            }
        }

        private fun drawLayer(canvas: Canvas, ref: String): Boolean {
            colorOf(ref)?.let { canvas.drawColor(it); return true }
            val isDrawable = ref.startsWith("@drawable/")
            val isMipmap = ref.startsWith("@mipmap/")
            if (!isDrawable && !isMipmap) return false
            val name = ref.substringAfterLast('/')
            val folder = if (isMipmap) "mipmap" else "drawable"
            if (isDrawable) {
                val xmlPath = paths.filter { it.startsWith(resDir + folder) && it.endsWith("/$name.xml") }.minByOrNull { it.length }
                if (xmlPath != null) {
                    val xml = text(xmlPath) ?: return false
                    return drawVector(canvas, xml, FULL.toFloat())
                }
            }
            val rasterName = Regex("/" + Regex.escape(name) + "\\.(png|webp)\\z")
            val raster = paths.filter { it.startsWith(resDir + folder) && rasterName.containsMatchIn(it) }
                .maxByOrNull { rasterScore(it) } ?: return false
            val bytes = source.read(raster) ?: return false
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return false
            canvas.drawBitmap(bmp, null, RectF(0f, 0f, FULL.toFloat(), FULL.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
            return true
        }

        private fun drawVector(canvas: Canvas, xml: String, size: Float): Boolean {
            var drew = false
            var saves = 0
            try {
                val p = Xml.newPullParser()
                p.setInput(StringReader(xml))
                var event = p.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "vector" -> {
                                val vw = attr(p, "viewportWidth")?.toFloatOrNull() ?: 108f
                                val vh = attr(p, "viewportHeight")?.toFloatOrNull() ?: 108f
                                canvas.save(); saves++
                                canvas.scale(size / vw, size / vh)
                            }
                            "group" -> {
                                canvas.save(); saves++
                                fun f(n: String, d: Float) = attr(p, n)?.toFloatOrNull() ?: d
                                val px = f("pivotX", 0f)
                                val py = f("pivotY", 0f)
                                canvas.translate(f("translateX", 0f), f("translateY", 0f))
                                canvas.translate(px, py)
                                canvas.rotate(f("rotation", 0f))
                                canvas.scale(f("scaleX", 1f), f("scaleY", 1f))
                                canvas.translate(-px, -py)
                            }
                            "path" -> if (drawPath(canvas, p)) drew = true
                            "solid" -> attr(p, "color")?.let { c -> colorOf(c)?.let { canvas.drawColor(it); drew = true } }
                        }
                    } else if (event == XmlPullParser.END_TAG && p.name == "group") {
                        canvas.restore(); saves--
                    }
                    event = p.next()
                }
            } catch (_: XmlPullParserException) {
            } finally {
                while (saves > 0) { canvas.restore(); saves-- }
            }
            return drew
        }

        private fun drawPath(canvas: Canvas, p: XmlPullParser): Boolean {
            val data = attr(p, "pathData") ?: return false
            val path: Path = try { PathParser.createPathFromPathData(data) } catch (_: RuntimeException) { null } ?: return false
            if (attr(p, "fillType") == "evenOdd") path.fillType = Path.FillType.EVEN_ODD
            var drew = false
            val fill = attr(p, "fillColor")?.let { colorOf(it) }
            if (fill != null) {
                val alpha = attr(p, "fillAlpha")?.toFloatOrNull() ?: 1f
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = ColorUtils.setAlphaComponent(fill, (Color.alpha(fill) * alpha).toInt().coerceIn(0, 255))
                }
                canvas.drawPath(path, paint)
                drew = true
            }
            val stroke = attr(p, "strokeColor")?.let { colorOf(it) }
            val width = attr(p, "strokeWidth")?.toFloatOrNull() ?: 0f
            if (stroke != null && width > 0f) {
                val alpha = attr(p, "strokeAlpha")?.toFloatOrNull() ?: 1f
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = width
                    color = ColorUtils.setAlphaComponent(stroke, (Color.alpha(stroke) * alpha).toInt().coerceIn(0, 255))
                    strokeCap = when (attr(p, "strokeLineCap")) {
                        "round" -> Paint.Cap.ROUND
                        "square" -> Paint.Cap.SQUARE
                        else -> Paint.Cap.BUTT
                    }
                    strokeJoin = when (attr(p, "strokeLineJoin")) {
                        "round" -> Paint.Join.ROUND
                        "bevel" -> Paint.Join.BEVEL
                        else -> Paint.Join.MITER
                    }
                }
                canvas.drawPath(path, paint)
                drew = true
            }
            return drew
        }
    }

    @Synchronized
    private fun store(slug: String, source: Bitmap): Boolean = try {
        val side = minOf(source.width, source.height)
        val square = Bitmap.createBitmap(source, (source.width - side) / 2, (source.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, SIZE, SIZE, true)
        file(slug).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        memory[slug] = scaled
        true
    } catch (_: Exception) {
        false
    }

    companion object {
        private const val SIZE = 192
        private const val FULL = 432 // 108dp x 4
        private const val MAX_ZIP_BYTES = 8L * 1024 * 1024
        private const val MAX_ENTRY_BYTES = 2L * 1024 * 1024
        private const val MAX_TOTAL_BYTES = 24L * 1024 * 1024

        /** "EnduranceVault" -> "EV", "Aplikasi Kasir" -> "AK", "dialchat" -> "DI". */
        fun initials(name: String): String {
            val words = name.split(' ', '-', '_', '.').filter { it.isNotBlank() }
            if (words.size >= 2) return "${words[0].first()}${words[1].first()}".uppercase()
            val word = words.firstOrNull().orEmpty()
            val caps = word.filter { it.isUpperCase() }
            return if (caps.length >= 2) caps.take(2) else word.take(2).uppercase()
        }
    }
}
