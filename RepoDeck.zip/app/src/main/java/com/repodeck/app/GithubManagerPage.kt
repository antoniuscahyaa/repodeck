package com.repodeck.app

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Halaman GitHub Manager (UI). Logika jaringan ada di [GithubApi], pemantauan/auto-download
 * di [GithubBuildMonitor]; kelas ini hanya menggambar halaman, kartu, dan dialog.
 */
class GithubManagerPage(private val host: MainActivity) : GithubBuildMonitor.Listener {

    val api = GithubApi(host)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val monitor = GithubBuildMonitor(host, api, executor, main).also { it.listener = this }

    private var githubSelectedRepo: String = api.prefs.getString("selected_repo", null)?.takeIf { api.repositories.contains(it) } ?: api.repositories.firstOrNull().orEmpty()
    private var githubPageRoot: LinearLayout? = null
    private var githubCardsBox: LinearLayout? = null
    private var githubStatusText: TextView? = null
    private var githubUploadCard: LinearLayout? = null
    private var githubUploadTitle: TextView? = null
    private var githubUploadDetail: TextView? = null
    private var githubUploadPercent: TextView? = null
    private var githubUploadProgress: ProgressBar? = null
    private var pendingGithubLog = ""
    private var githubHistoryExpanded = false
    private var githubRunDialog: AlertDialog? = null
    private var githubRunDialogView: LinearLayout? = null
    private var githubRunDialogScroll: ScrollView? = null
    private var githubRunDialogId: Long = 0L
    private var githubRunDetailInFlight = false
    private var githubAutoBuildRunId: Long = 0L
    private var githubAutoBuildRunName: String = "Build APK"
    private var githubAutoBuildRepoSlug: String = ""
    private var githubActiveUploadRepoSlug: String = ""
    private var githubRunDialogRepoSlug: String = ""
    private var githubRunDialogSignature: String = ""
    private var githubRunDialogInfoLabel: TextView? = null
    private var githubRunDialogFinished = false
    private val githubRunDialogHandler = Handler(Looper.getMainLooper())

    // ---------------------------------------------------------------- helper UI milik MainActivity
    private fun dp(value: Int): Int = host.dp(value)
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = host.label(text, size, color, bold)
    private fun sectionTitle(text: String, size: Float = 17f): TextView = host.sectionTitle(text, size)
    private fun actionSetting(title: String, description: String, action: () -> Unit): View = host.actionSetting(title, description, action)
    private fun infoCard(title: String, description: String, action: String?, onClick: () -> Unit): View = host.infoCard(title, description, action, onClick)
    private fun pressable(fill: Int, radiusDp: Int, stroke: Boolean): android.graphics.drawable.Drawable = host.pressable(fill, radiusDp, stroke)
    private fun roundedBackground(color: Int, radius: Float): android.graphics.drawable.GradientDrawable = host.roundedBackground(color, radius)
    private fun cardBackground(): android.graphics.drawable.GradientDrawable = host.cardBackground()
    private fun primaryText(): Int = host.primaryText()
    private fun secondaryText(): Int = host.secondaryText()
    private fun accentColor(): Int = host.accentColor()
    private fun onAccent(): Int = host.onAccent()
    private fun cardColor(): Int = host.cardColor()
    private fun styleField(et: EditText) = host.styleField(et)
    private fun AlertDialog.showStyled() = host.showStyledDialog(this)
    private fun AlertDialog.Builder.showStyled(): AlertDialog = create().also { host.showStyledDialog(it) }

    // ---------------------------------------------------------------- siklus hidup
    fun startMonitoring() = monitor.start()

    fun setForeground(value: Boolean) = monitor.setForeground(value)

    fun shutdown() {
        monitor.stop()
        main.removeCallbacksAndMessages(null)
        githubRunDialogHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
    }

    fun saveLogTo(uri: Uri) {
        try {
            host.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingGithubLog) }
                ?: throw IllegalStateException("File tujuan tidak dapat dibuka")
            Toast.makeText(host, "Log berhasil disimpan", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(host, "Gagal menyimpan log: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- GithubBuildMonitor.Listener
    override fun isPageVisible(): Boolean = host.isGithubSection()

    override fun selectedRepoSlug(): String = if (githubExpanded && githubSelectedRepo.isNotBlank()) api.repositorySlug(githubSelectedRepo) else ""

    override fun onTick() { if (githubExpanded) loadRepoRuns(githubSelectedRepo, true) }

    override fun onRunsUpdated(repoSlug: String) {
        refreshChips()
        if (host.isGithubSection()) refreshCard(api.displayNameForSlug(repoSlug))
        refreshBuildTab()
    }

    override fun onRunCompleted(repoSlug: String, runId: Long, runName: String, conclusion: String) {
        refreshChips()
        refreshBuildTab(true)
        if (host.isGithubSection()) {
            repoCards.values.forEach { it.signature = "" }
            refreshCard(api.displayNameForSlug(repoSlug))
        }
        if (!host.isGithubSection() || api.repositorySlug(githubSelectedRepo) != repoSlug) return
        val card = githubUploadCard
        if (card != null && card.visibility == View.VISIBLE && card.tag == null) return // upload sedang berjalan
        // Kartu hasil tampil walau dialog progress sudah ditutup.
        showGithubBuildResultCard(runId, runName, repoSlug, conclusion)
    }

    override fun onRateLimited(untilMs: Long, message: String) {
        githubStatusText?.text = message
        if (host.isGithubSection()) Toast.makeText(host, message, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- status & kartu hasil
    private fun updateStatusText() {
        githubStatusText?.text = when {
            !api.configured() -> "Belum terhubung · atur akun GitHub terlebih dahulu"
            api.isRateLimited() -> api.rateLimitMessage(api.rateLimitedUntilMs)
            else -> "Terhubung sebagai ${api.owner()}"
        }
    }

    /** Menampilkan hasil build terakhir (maks. 6 jam) yang belum ditutup, bila kartu sedang bebas. */
    private fun showStoredResultCard(repoSlug: String) {
        val card = githubUploadCard ?: return
        val tag = card.tag as? String
        if (card.visibility == View.VISIBLE && tag?.startsWith("result_") != true) return // kartu upload/running sedang dipakai
        val result = monitor.lastResult(repoSlug) ?: return
        if (monitor.isProgressDismissed(repoSlug, result.runId)) return
        showGithubBuildResultCard(result.runId, result.name, repoSlug, result.conclusion)
    }



    /** Akun diatur di tab Akun. */
    fun showGithubAccountDialog() {
        Toast.makeText(host, "Isi username dan token GitHub di tab Akun", Toast.LENGTH_LONG).show()
        host.selectTab(2)
    }


    private fun maybeOpenUploadedBuildMonitor(displayRepo: String, repoSlug: String, runs: JSONArray) {
        if (!host.isGithubSection() || githubSelectedRepo != displayRepo) return
        val runId = api.prefs.getLong("github_auto_build_run_$repoSlug", 0L)
        if (runId <= 0L) return
        val run = (0 until runs.length()).map { runs.optJSONObject(it) }.firstOrNull { it?.optLong("id") == runId } ?: return
        monitor.transferPendingProgressDismiss(repoSlug, runId)
        val name = run.optString("name", "Build APK")
        githubAutoBuildRunId = runId
        githubAutoBuildRunName = name
        githubAutoBuildRepoSlug = repoSlug
        if (run.optString("status") == "completed") return
        showGithubBuildRunningCard(runId, name, repoSlug)
        // Auto-open the progress dialog only ONCE per build. After the user closes it
        // (or dismisses the card) it must never pop up again; the card can still be tapped.
        val openedKey = "github_dialog_auto_opened_${repoSlug}_$runId"
        if (api.prefs.getBoolean(openedKey, false) || monitor.isProgressDismissed(repoSlug, runId)) return
        api.prefs.edit().putBoolean(openedKey, true).apply()
        if (githubRunDialog?.isShowing != true) showGithubRunJobs(runId, name, repoSlug)
    }

    private fun dismissGithubProgressCard(repoSlug: String, runId: Long) {
        val key = if (runId > 0L) monitor.progressDismissKey(repoSlug, runId) else monitor.pendingProgressDismissKey(repoSlug)
        api.prefs.edit().putBoolean(key, true).commit()
        githubUploadCard?.visibility = View.GONE
        githubUploadCard?.setOnClickListener(null)
        githubUploadCard?.isClickable = false
    }

    private fun addGithubProgressDismissButton(row: LinearLayout, repoSlug: String, runId: Long) {
        row.addView(label("×", 22f, secondaryText(), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(2), 0)
            setOnClickListener { dismissGithubProgressCard(repoSlug, runId) }
        })
    }

    private fun showGithubBuildRunningCard(runId: Long, runName: String, repoSlug: String) {
        val card = githubUploadCard ?: return
        if (monitor.isProgressDismissed(repoSlug, runId) ||
            (runId > 0L && api.prefs.getBoolean(monitor.pendingProgressDismissKey(repoSlug), false))) {
            card.visibility = View.GONE; card.setOnClickListener(null); return
        }
        val cardTag = "running_${repoSlug}_$runId"
        if (card.visibility == View.VISIBLE && card.tag == cardTag) return // already shown; avoid rebuilding every poll
        card.tag = cardTag
        card.removeAllViews()
        card.visibility = View.VISIBLE
        card.setPadding(dp(14), dp(11), dp(14), dp(11))
        val row = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("Build sedang berjalan", 13f, primaryText(), true))
            addView(label("${api.displayNameForSlug(repoSlug)} · $runName · Ketuk untuk melihat progress", 11f, secondaryText()).apply {
                setPadding(0, dp(3), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addGithubProgressDismissButton(row, repoSlug, runId)
        card.addView(row)
        card.setOnClickListener {
            if (githubRunDialog?.isShowing != true) showGithubRunJobs(runId, runName, repoSlug)
        }
    }

    private fun showGithubBuildResultCard(runId: Long, runName: String, repoSlug: String, conclusion: String) {
        val card = githubUploadCard ?: return
        if (monitor.isProgressDismissed(repoSlug, runId) ||
            (runId > 0L && api.prefs.getBoolean(monitor.pendingProgressDismissKey(repoSlug), false))) {
            card.visibility = View.GONE; card.setOnClickListener(null); return
        }
        val cardTag = "result_${repoSlug}_$runId"
        if (card.visibility == View.VISIBLE && card.tag == cardTag) return // already shown
        card.tag = cardTag
        card.removeAllViews()
        card.visibility = View.VISIBLE
        card.setPadding(dp(14), dp(11), dp(14), dp(11))
        val success = conclusion == "success"
        val title = GithubBuildMonitor.resultTitle(conclusion)
        val color = when (conclusion) {
            "success" -> Color.rgb(35, 150, 85)
            "cancelled" -> Color.rgb(200, 140, 30)
            else -> Color.rgb(205, 65, 65)
        }
        val row = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(if (success) "✓" else "!", 22f, color, true))
        row.addView(LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(title, 14f, primaryText(), true))
            addView(label("${api.displayNameForSlug(repoSlug)} · $runName · Ketuk untuk detail", 11f, secondaryText()))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10) })
        if (success) {
            row.addView(linkText("Install") {
                Toast.makeText(host, "Menyiapkan APK…", Toast.LENGTH_SHORT).show()
                monitor.downloadRunArtifacts(repoSlug, runId, true)
            })
        }
        addGithubProgressDismissButton(row, repoSlug, runId)
        card.addView(row)
        card.setOnClickListener { showGithubRunJobs(runId, runName, repoSlug) }
    }

    private fun showGithubRunJobs(runId: Long, runName: String, repoSlug: String = api.repositorySlug(githubSelectedRepo)) {
        githubRunDialogRepoSlug = repoSlug
        githubRunDialogSignature = ""
        githubRunDialogInfoLabel = null
        githubRunDialogFinished = false
        githubRunDialogId = runId
        val dialogView = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val scroll = ScrollView(host).apply { isFillViewport = true; addView(dialogView) }
        val dialog = AlertDialog.Builder(host).setTitle(runName).setView(scroll).setNegativeButton("Tutup", null).create()
        githubRunDialog = dialog
        githubRunDialogView = dialogView
        githubRunDialogScroll = scroll
        dialog.setOnDismissListener {
            githubRunDialogHandler.removeCallbacksAndMessages(null)
            githubRunDialog = null; githubRunDialogView = null; githubRunDialogScroll = null; githubRunDialogId = 0L
            githubRunDialogInfoLabel = null; githubRunDialogSignature = ""
        }
        dialog.showStyled()
        refreshGithubRunJobs()
        val refreshRunnable = object : Runnable {
            override fun run() {
                // Auto-refresh every 1 second until the run has finished.
                if (githubRunDialog?.isShowing == true && githubRunDialogId == runId && !githubRunDialogFinished) {
                    refreshGithubRunJobs()
                    githubRunDialogHandler.postDelayed(this, 1000L)
                }
            }
        }
        githubRunDialogHandler.postDelayed(refreshRunnable, 1000L)
    }

    private fun refreshGithubRunJobs() {
        val runId = githubRunDialogId
        val view = githubRunDialogView ?: return
        if (runId == 0L || githubRunDetailInFlight) return
        githubRunDetailInFlight = true
        val repoSlug = githubRunDialogRepoSlug.ifBlank { api.repositorySlug(githubSelectedRepo) }; val owner = api.ownerFor(repoSlug)
        if (view.childCount == 0) {
            view.addView(label("Memuat detail build…", 12f, secondaryText()))
        }
        val previousScrollY = githubRunDialogScroll?.scrollY ?: 0
        executor.execute {
            try {
                val runJson = JSONObject(api.request("/repos/$owner/$repoSlug/actions/runs/$runId"))
                val jobs = JSONObject(api.request("/repos/$owner/$repoSlug/actions/runs/$runId/jobs?per_page=100")).optJSONArray("jobs") ?: JSONArray()
                var totalSteps = 0; var completedSteps = 0
                val jobData = mutableListOf<JSONObject>()
                for (i in 0 until jobs.length()) {
                    val job = jobs.getJSONObject(i); jobData.add(job)
                    val steps = job.optJSONArray("steps") ?: JSONArray()
                    for (j in 0 until steps.length()) {
                        totalSteps++
                        if (steps.getJSONObject(j).optString("status") == "completed") completedSteps++
                    }
                }
                val percent = if (totalSteps == 0) 0 else (completedSteps * 100 / totalSteps)
                val duration = api.formatDuration(runJson.optString("run_started_at", runJson.optString("created_at")), runJson.optString("updated_at").takeIf { runJson.optString("status") == "completed" } ?: "")
                main.post {
                    githubRunDetailInFlight = false
                    try {
                    if (githubRunDialogId != runId || githubRunDialogView !== view) return@post
                    val signature = buildString {
                        append(runJson.optString("status")).append('|').append(runJson.optString("conclusion"))
                            .append('|').append(completedSteps).append('/').append(totalSteps)
                        for (job in jobData) {
                            append('#').append(job.optLong("id")).append(job.optString("status")).append(job.optString("conclusion"))
                            val st = job.optJSONArray("steps") ?: JSONArray()
                            for (k in 0 until st.length()) {
                                val sj = st.getJSONObject(k)
                                append(',').append(sj.optString("status")).append(sj.optString("conclusion"))
                            }
                        }
                    }
                    if (runJson.optString("status") == "completed") githubRunDialogFinished = true
                    if (signature == githubRunDialogSignature && view.childCount > 0) {
                        // Nothing changed: only tick the duration, don't rebuild (no flicker, taps aren't lost).
                        githubRunDialogInfoLabel?.text = "Tahapan selesai: $completedSteps / $totalSteps · Durasi $duration"
                        return@post
                    }
                    githubRunDialogSignature = signature
                    view.removeAllViews()
                    val summary = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    summary.addView(label("${runJson.optString("status")} · ${runJson.optString("conclusion").ifBlank { "berjalan" }}", 13f, primaryText(), true),
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    summary.addView(label("$percent%", 20f, accentColor(), true))
                    view.addView(summary)
                    val bar = ProgressBar(host, null, android.R.attr.progressBarStyleHorizontal).apply {
                        max = 100; progress = percent; progressTintList = android.content.res.ColorStateList.valueOf(accentColor())
                    }
                    view.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)).apply { topMargin = dp(8); bottomMargin = dp(8) })
                    view.addView(label("Tahapan selesai: $completedSteps / $totalSteps · Durasi $duration", 11f, secondaryText()).also { githubRunDialogInfoLabel = it })
                    view.addView(sectionTitle("Jobs & steps", 14f))
                    for (job in jobData) {
                        val jobName = job.optString("name", "Job")
                        val jobStatus = job.optString("status")
                        val jobConclusion = job.optString("conclusion")
                        view.addView(actionSetting(jobName, "$jobStatus · ${jobConclusion.ifBlank { "running" }} · Buka log") {
                            showGithubJobLog(owner, repoSlug, job.optLong("id"), jobName)
                        })
                        val steps = job.optJSONArray("steps") ?: JSONArray()
                        for (j in 0 until steps.length()) {
                            val step = steps.getJSONObject(j)
                            val state = if (step.optString("status") == "completed") step.optString("conclusion") else step.optString("status")
                            view.addView(label("   ${step.optInt("number")}. ${step.optString("name")} · $state", 11f, secondaryText()).apply {
                                setPadding(dp(8), dp(3), 0, dp(3))
                            })
                        }
                    }
                    if (jobData.isEmpty()) view.addView(label("GitHub belum menerbitkan detail job.", 12f, secondaryText()))
                    val refresh = TextView(host).apply {
                        text = "↻  Refresh progress"
                        setTextColor(accentColor()); setTypeface(null, Typeface.BOLD); setPadding(0, dp(12), 0, dp(6))
                        setOnClickListener { refreshGithubRunJobs() }
                    }
                    view.addView(refresh)
                    if (runJson.optString("status") == "completed") {
                        val success = runJson.optString("conclusion") == "success"
                        val note = if (!success) "Log kegagalan akan diunduh otomatis jika arsip sudah tersedia." else "Artifact build akan diunduh otomatis jika workflow mengunggah artifact."
                        view.addView(label(note, 11f, secondaryText()).apply { setPadding(0, dp(8), 0, 0) })
                        if (githubAutoBuildRunId == runId && githubAutoBuildRepoSlug == repoSlug) {
                            val completedName = runJson.optString("name", githubAutoBuildRunName)
                            val completedRepo = githubAutoBuildRepoSlug
                            githubAutoBuildRunId = 0L
                            githubRunDialog?.dismiss()
                            showGithubBuildResultCard(runId, completedName, completedRepo, runJson.optString("conclusion"))
                        }
                    }
                    // Keep the dialog at the same scroll position after each refresh.
                    val monitorScroll = githubRunDialogScroll
                    monitorScroll?.post {
                        val maxScroll = (view.height - monitorScroll.height).coerceAtLeast(0)
                        monitorScroll.scrollTo(0, previousScrollY.coerceAtMost(maxScroll))
                    }
                    } catch (ex: Exception) {
                        CrashLogger.record(host, ex, "run dialog render")
                    }
                }
            } catch (e: Exception) {
                main.post {
                    monitor.reportError(e)
                    githubRunDetailInFlight = false
                    if (githubRunDialogId == runId && githubRunDialogView === view && view.childCount == 0) {
                        view.addView(label(e.message ?: "Gagal memuat detail build", 12f, secondaryText()))
                    }
                }
            }
        }
    }

    private fun showGithubJobLog(owner: String, repoSlug: String, jobId: Long, jobName: String) {
        executor.execute {
            try {
                val log = api.fetchJobLog(owner, repoSlug, jobId)
                main.post {
                    pendingGithubLog = log
                    val text = TextView(host).apply {
                        this.text = log.take(45000) + if (log.length > 45000) "\n\n… pratinjau dipotong. Gunakan tombol Unduh log untuk menyimpan file lengkap." else ""
                        textSize = 11f; setTextColor(primaryText()); setPadding(dp(14), dp(12), dp(14), dp(12))
                        typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
                    }
                    val sc = ScrollView(host).apply { addView(text) }
                    val safeName = "${repoSlug}_${jobName}".replace(Regex("[^A-Za-z0-9._-]+"), "_").take(70)
                    AlertDialog.Builder(host).setTitle(jobName).setView(sc).setNegativeButton("Tutup", null)
                        .setPositiveButton("Unduh log") { _, _ -> host.launchGithubLogSaver("${safeName}_job_$jobId.txt") }.showStyled()
                }
            } catch (e: Exception) {
                main.post {
                    if (e is GithubRateLimitException) monitor.reportError(e)
                    else Toast.makeText(host, e.message ?: "Gagal mengambil log", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showGithubUploadProgress(fileName: String, visible: Boolean) {
        val repoSlug = githubActiveUploadRepoSlug.ifBlank { api.repositorySlug(githubSelectedRepo) }
        if (visible && api.prefs.getBoolean(monitor.pendingProgressDismissKey(repoSlug), false)) {
            githubUploadCard?.visibility = View.GONE
            return
        }
        githubUploadCard?.setOnClickListener(null)
        githubUploadCard?.tag = null
        githubUploadCard?.removeAllViews()
        githubUploadCard?.visibility = if (visible) View.VISIBLE else View.GONE
        githubUploadTitle?.text = if (visible) "Mengunggah $fileName" else "Mengunggah ZIP"
        val card = githubUploadCard ?: return
        val titleRow = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = label("Mengunggah $fileName", 14f, primaryText(), true)
        githubUploadTitle = title
        titleRow.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addGithubProgressDismissButton(titleRow, repoSlug, 0L)
        val percent = label("0%", 16f, accentColor(), true)
        githubUploadPercent = percent
        titleRow.addView(percent)
        card.addView(titleRow)
        val detail = label("Menyiapkan file…", 11f, secondaryText())
        githubUploadDetail = detail
        detail.setPadding(0, dp(4), 0, dp(8))
        card.addView(detail)
        val progress = ProgressBar(host, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(accentColor())
        }
        githubUploadProgress = progress
        card.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)))
    }

    private fun updateGithubUploadProgress(percent: Int, sent: Long, total: Long, status: String? = null) {
        githubUploadPercent?.text = if (status == null) "$percent%" else ""
        githubUploadProgress?.progress = percent
        val mbSent = sent / (1024.0 * 1024.0)
        val mbTotal = total / (1024.0 * 1024.0)
        githubUploadDetail?.text = status ?: "%.1f MB / %.1f MB dikirim ke GitHub".format(Locale.US, mbSent, mbTotal)
    }



    // ================================================================ halaman kartu per repo

    private class RepoCard(
        val displayName: String,
        val slug: String,
        val root: LinearLayout,
        val info: TextView,
        val pill: TextView,
        val chevron: TextView,
        val quick: TextView,
        val body: LinearLayout,
        val stepper: LinearLayout,
        val history: LinearLayout,
        val runs: LinearLayout
    ) {
        var signature: String = ""
    }

    private val repoCards = LinkedHashMap<String, RepoCard>()
    private val runsInFlight = HashSet<String>()
    private val historyCache = ConcurrentHashMap<String, JSONArray>()
    /** Pesan gagal muat per bagian kartu: kunci "h:<slug>" (riwayat) dan "r:<slug>" (workflow). */
    private val loadFailed = ConcurrentHashMap<String, String>()
    private var githubExpanded = true
    private var pendingUploadRepo: String? = null
    private var uploadingSlug: String? = null

    private fun fmtMb(bytes: Long): String = "%.2f MB".format(Locale.US, bytes / (1024.0 * 1024.0))

    private fun parseIsoMs(text: String): Long = try { Instant.parse(text).toEpochMilli() } catch (_: Exception) { 0L }

    private fun fmtDateMs(ms: Long): String = api.formatTimestamp(Instant.ofEpochMilli(ms).toString())

    private fun linkText(text: String, onClick: () -> Unit): TextView = TextView(host).apply {
        this.text = text
        textSize = 12f
        setTypeface(null, Typeface.BOLD)
        setTextColor(accentColor())
        setPadding(dp(8), dp(6), dp(4), dp(6))
        setOnClickListener { onClick() }
    }

    private fun newPill(): TextView = TextView(host).apply {
        textSize = 11f
        setTypeface(null, Typeface.BOLD)
        setPadding(dp(8), dp(3), dp(8), dp(3))
    }

    private fun applyPill(tv: TextView, text: String, kind: String) {
        val colors = when (kind) {
            "ok" -> Pair(Color.rgb(223, 245, 230), Color.rgb(24, 94, 52))
            "bad" -> Pair(Color.rgb(253, 226, 226), Color.rgb(153, 27, 27))
            "acc" -> Pair(Color.rgb(219, 234, 254), Color.rgb(30, 64, 175))
            "warn" -> Pair(Color.rgb(254, 243, 199), Color.rgb(120, 53, 15))
            else -> Pair(cardColor(), secondaryText())
        }
        tv.text = text
        tv.setTextColor(colors.second)
        tv.background = roundedBackground(colors.first, dp(10).toFloat())
    }

    private fun dotView(color: Int): View = View(host).apply {
        background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(color)
        }
    }

    private fun divider(): View = View(host).apply {
        setBackgroundColor(Color.argb(40, 128, 128, 128))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    }

    private fun compactRow(dotColor: Int?, title: String, meta: String, trailing: View?, onClick: (() -> Unit)?): View {
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        if (dotColor != null) {
            row.addView(dotView(dotColor), LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(10) })
        }
        val column = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        column.addView(label(title, 13f, primaryText(), true))
        column.addView(label(meta, 11f, secondaryText()))
        row.addView(column, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)
        if (onClick != null) {
            row.isClickable = true
            row.setOnClickListener { onClick() }
        }
        return row
    }

    // ================================================================ tab Repo

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private var chipsBox: LinearLayout? = null
    private var buildTabBox: LinearLayout? = null
    private var buildTabSignature: String = ""
    private var accountBox: LinearLayout? = null

    private fun roundButton(text: String, description: String, onClick: () -> Unit): TextView = TextView(host).apply {
        this.text = text
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(primaryText())
        contentDescription = description
        background = pressable(cardColor(), 22, false)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private val icons = RepoIcons(host, api)
    private val iconFetching = mutableSetOf<String>()
    private var chipsSignature = ""
    private var lastActiveTapAt = 0L

    private fun ovalOutline() = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }

    private fun ovalBackground(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** Warna latar dan teks inisial, tetap per repo (dari hash slug) agar mudah dibedakan. */
    private fun repoTint(name: String): Pair<Int, Int> {
        val hue = (Math.abs(api.repositorySlug(name).hashCode().toLong()) % 360L).toFloat()
        val night = (host.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val bg = Color.HSVToColor(48, floatArrayOf(hue, 0.60f, 0.90f))
        val fg = Color.HSVToColor(floatArrayOf(hue, 0.65f, if (night) 0.95f else 0.55f))
        return Pair(bg, fg)
    }

    /** Ikon aplikasi repo; jika belum ada, lingkaran inisial berwarna. */
    private fun repoIconView(name: String, sizeDp: Int): View {
        val bmp = icons.bitmap(api.repositorySlug(name))
        if (bmp != null) {
            return ImageView(host).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
                outlineProvider = ovalOutline()
                clipToOutline = true
            }
        }
        val (bg, fg) = repoTint(name)
        return TextView(host).apply {
            text = RepoIcons.initials(name)
            textSize = if (sizeDp >= 40) 14f else 12f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(fg)
            background = ovalBackground(bg)
        }
    }

    private fun rippleOval(): android.graphics.drawable.Drawable =
        RippleDrawable(
            ColorStateList.valueOf(androidx.core.graphics.ColorUtils.setAlphaComponent(primaryText(), 36)),
            null, ovalBackground(Color.BLACK)
        )

    private fun rippleOver(base: android.graphics.drawable.Drawable, radiusDp: Int): android.graphics.drawable.Drawable =
        RippleDrawable(
            ColorStateList.valueOf(androidx.core.graphics.ColorUtils.setAlphaComponent(primaryText(), 36)),
            base, roundedBackground(Color.BLACK, dp(radiusDp).toFloat())
        )

    /** Warna titik status, atau null bila belum ada data. */
    private fun statusDotColor(kind: String): Int? = when (kind) {
        "acc" -> accentColor()
        "ok" -> Color.rgb(34, 150, 83)
        "bad" -> Color.rgb(205, 65, 65)
        "warn" -> Color.rgb(217, 140, 20)
        else -> null
    }

    private fun statusDot(kind: String): View? {
        val color = statusDotColor(kind) ?: return null
        val dot = View(host).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(2), host.surfaceColor())
            }
        }
        if (kind == "acc") {
            val pulse = android.animation.ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.3f).apply {
                duration = 700
                repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
            }
            dot.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) { pulse.start() }
                override fun onViewDetachedFromWindow(v: View) { pulse.cancel() }
            })
        }
        return dot
    }

    /** Repo tidak aktif: ikon bulat 44dp dengan titik status di sudut. */
    private fun iconTile(name: String, onClick: () -> Unit): View = FrameLayout(host).apply {
        val status = pillFor(api.repositorySlug(name))
        background = ovalBackground(cardColor())
        addView(repoIconView(name, 44), FrameLayout.LayoutParams(MATCH, MATCH))
        statusDot(status.second)?.let {
            addView(it, FrameLayout.LayoutParams(dp(13), dp(13), Gravity.TOP or Gravity.END).apply {
                topMargin = 0; marginEnd = 0
            })
        }
        foreground = rippleOval()
        contentDescription = if (status.second == "neutral") name else "$name, ${status.first}"
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        setOnLongClickListener { showRepoIconDialog(name); true }
    }

    /** Repo aktif: pill outline aksen berisi ikon kecil, nama, dan status build. */
    private fun activePill(name: String): View = LinearLayout(host).apply {
        val status = pillFor(api.repositorySlug(name))
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(6), 0, dp(16), 0)
        background = rippleOver(
            GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(22).toFloat()
                setStroke(dp(2), accentColor())
            }, 22
        )
        addView(repoIconView(name, 32), LinearLayout.LayoutParams(dp(32), dp(32)))
        val texts = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(host).apply {
            text = name
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(accentColor())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (status.second != "neutral") {
            texts.addView(TextView(host).apply {
                text = status.first
                textSize = 11f
                setTextColor(statusDotColor(status.second) ?: secondaryText())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) })
        contentDescription = "$name, dipilih. Ketuk dua kali untuk menyegarkan"
        isClickable = true
        isFocusable = true
        // Ketuk dua kali = segarkan repo ini (pengganti tombol ↻ yang jauh dari jempol).
        setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - lastActiveTapAt < 400L) { lastActiveTapAt = 0L; refreshRepoNow(name) } else lastActiveTapAt = now
        }
        setOnLongClickListener { showRepoIconDialog(name); true }
    }

    private fun refreshRepoNow(name: String) {
        if (!api.configured()) { showGithubAccountDialog(); return }
        Toast.makeText(host, "Menyegarkan $name…", Toast.LENGTH_SHORT).show()
        historyCache.remove(api.repositorySlug(name))
        loadRepoRuns(name, false)
        loadHistory(name)
    }

    private fun addTile(): View = TextView(host).apply {
        text = "+"
        textSize = 20f
        gravity = Gravity.CENTER
        setTextColor(primaryText())
        contentDescription = "Tambah repo"
        background = pressable(cardColor(), 12, false)
        isClickable = true
        isFocusable = true
        setOnClickListener { showAddRepoDialog() }
    }

    private fun chipsSig(): String = api.repositories.joinToString("|") { name ->
        val status = pillFor(api.repositorySlug(name))
        "$name:${name == githubSelectedRepo}:${status.first}:${icons.has(api.repositorySlug(name))}"
    }

    /** Bangun ulang pill hanya bila ada yang berubah (urutan, pilihan, status, ikon). */
    private fun refreshChips() {
        if (chipsBox == null) return
        if (chipsSig() != chipsSignature) rebuildChips()
    }

    /** [previous] = repo aktif sebelumnya; bila diberikan, perpindahan dianimasikan. */
    private fun rebuildChips(previous: String? = null) {
        val box = chipsBox ?: return
        box.removeAllViews()
        chipsSignature = chipsSig()
        api.repositories.forEach { name ->
            if (name == githubSelectedRepo) {
                val pill = activePill(name)
                box.addView(pill, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
                if (previous != null && previous != name) {
                    pill.pivotX = 0f
                    pill.scaleX = 0.6f
                    pill.alpha = 0.4f
                    pill.animate().scaleX(1f).alpha(1f).setDuration(220)
                        .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
                }
            } else {
                val tile = iconTile(name) { selectRepo(name) }
                box.addView(tile, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })
                if (previous == name) {
                    tile.scaleX = 1.3f
                    tile.scaleY = 1.3f
                    tile.alpha = 0.6f
                    tile.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220)
                        .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
                }
            }
        }
        box.addView(addTile(), LinearLayout.LayoutParams(dp(44), dp(44)))
        fetchMissingIcons()
    }

    /** Ambil ikon PNG dari repo sekali per repo bila belum ada dan belum pernah dicoba. */
    private fun fetchMissingIcons() {
        if (!api.configured()) return
        api.repositories.forEach { name ->
            val slug = api.repositorySlug(name)
            if (icons.has(slug) || icons.triedAuto(slug) || !iconFetching.add(slug)) return@forEach
            executor.execute {
                try {
                    val found = icons.fetchFromRepo(slug)
                    icons.markTried(slug)
                    if (found) main.post { rebuildChips() }
                } catch (_: Exception) {
                    // Jaringan atau kuota gagal: coba lagi pada pembangunan berikutnya.
                } finally {
                    main.post { iconFetching.remove(slug) }
                }
            }
        }
    }

    private fun showRepoIconDialog(name: String) {
        val slug = api.repositorySlug(name)
        val index = api.repositories.indexOf(name)
        val last = api.repositories.size - 1
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        fun add(label: String, block: () -> Unit) { actions.add(Pair(label, block)) }
        add("Pilih ikon dari galeri") { host.launchRepoIconPicker(name) }
        add("Ambil ikon dari repo") {
            icons.resetTried(slug)
            Toast.makeText(host, "Mencari ikon di repo…", Toast.LENGTH_SHORT).show()
            executor.execute {
                val result = try { icons.fetchFromRepo(slug).also { icons.markTried(slug) } } catch (_: Exception) { null }
                main.post {
                    when (result) {
                        true -> rebuildChips()
                        false -> Toast.makeText(host, "Ikon aplikasi tidak ditemukan di repo maupun di ZIP-nya. Pilih dari galeri.", Toast.LENGTH_LONG).show()
                        null -> Toast.makeText(host, "Gagal mengambil ikon. Coba lagi nanti.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        add("Hapus ikon") { icons.remove(slug); rebuildChips() }
        if (index > 0) {
            add("Pindah ke paling kiri") { moveRepo(name, 0) }
            add("Geser ke kiri") { moveRepo(name, index - 1) }
        }
        if (index in 0 until last) add("Geser ke kanan") { moveRepo(name, index + 1) }
        AlertDialog.Builder(host).setTitle(name)
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .showStyled()
    }

    private fun moveRepo(name: String, toIndex: Int) {
        api.moveCustomRepo(name, toIndex)
        rebuildChips()
        renderAccountTab()
    }

    fun onRepoIconPicked(name: String, uri: Uri) {
        val slug = api.repositorySlug(name)
        executor.execute {
            val ok = icons.saveFromUri(slug, uri)
            main.post {
                if (ok) rebuildChips() else Toast.makeText(host, "Gambar tidak bisa dibaca.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun emptyReposCard(): View {
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(20))
            background = cardBackground()
        }
        box.addView(label("Belum ada repo", 16f, primaryText(), true))
        box.addView(label("Tambahkan repository GitHub untuk mulai mengunggah ZIP dan memantau build.", 13f, secondaryText()).apply {
            setPadding(0, dp(6), 0, dp(14))
        })
        box.addView(label("Tambah repo", 14f, onAccent(), true).apply {
            gravity = Gravity.CENTER
            background = pressable(accentColor(), 24, false)
            setPadding(dp(18), dp(13), dp(18), dp(13))
            isClickable = true
            isFocusable = true
            setOnClickListener { showAddRepoDialog() }
        })
        return box
    }

    fun buildPage(): View {
        val frame = FrameLayout(host)
        val scroll = ScrollView(host)
        val page = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(110))
        }
        scroll.addView(page)
        frame.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        githubPageRoot = page
        repoCards.clear()

        val top = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("RepoDeck", 24f, primaryText(), true))
        val status = label("", 13f, secondaryText())
        githubStatusText = status
        titles.addView(status)
        top.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(roundButton("↻", "Segarkan") {
            if (!api.configured()) showGithubAccountDialog()
            else api.repositories.forEach { loadRepoRuns(it, false); loadHistory(it) }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        page.addView(top)

        val chipsScroll = HorizontalScrollView(host).apply { isHorizontalScrollBarEnabled = false; isFillViewport = true }
        val chips = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL }
        chipsBox = chips
        chipsScroll.addView(chips)
        page.addView(chipsScroll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16); bottomMargin = dp(16) })
        rebuildChips()

        val cardsBox = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        githubCardsBox = cardsBox
        page.addView(cardsBox)
        rebuildCards()
        page.addView(label("Catatan: workflow berjalan otomatis jika YAML repository mengaktifkan trigger push untuk branch default. RepoDeck tidak mengubah file YAML.", 12f, secondaryText()).apply {
            setPadding(0, dp(14), 0, 0)
        })

        // Kartu progres upload mengambang di bagian bawah.
        val uploadCard = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = cardBackground()
            elevation = dp(8).toFloat()
            visibility = View.GONE
        }
        githubUploadCard = uploadCard
        val titleRow = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(label("Mengunggah ZIP", 14f, primaryText(), true).also { githubUploadTitle = it },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        titleRow.addView(label("0%", 16f, accentColor(), true).also { githubUploadPercent = it })
        uploadCard.addView(titleRow)
        uploadCard.addView(label("Menyiapkan file…", 11f, secondaryText()).also { githubUploadDetail = it }.apply {
            setPadding(0, dp(4), 0, dp(8))
        })
        uploadCard.addView(ProgressBar(host, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(accentColor())
            githubUploadProgress = this
        }, LinearLayout.LayoutParams(MATCH, dp(7)))
        frame.addView(uploadCard, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = dp(16); rightMargin = dp(16); bottomMargin = dp(12)
        })

        renderGithubPage()
        return frame
    }

    // ================================================================ tab Build

    private class BuildEntry(val slug: String, val run: JSONObject)

    fun buildBuildTab(): View {
        val scroll = ScrollView(host)
        val page = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(page)
        buildTabBox = page
        refreshBuildTab(true)
        return scroll
    }

    fun refreshBuildTab(force: Boolean = false) {
        val box = buildTabBox ?: return
        val entries = mutableListOf<BuildEntry>()
        for ((slug, arr) in monitor.runsCache) {
            for (i in 0 until arr.length()) {
                val run = arr.optJSONObject(i) ?: continue
                entries.add(BuildEntry(slug, run))
            }
        }
        entries.sortByDescending { parseIsoMs(it.run.optString("created_at")) }
        val shown = entries.take(20)
        val signature = shown.joinToString(";") {
            "${it.slug}${it.run.optLong("id")}${it.run.optString("status")}${it.run.optString("conclusion")}"
        } + "|" + api.configured()
        if (!force && signature == buildTabSignature && box.childCount > 0) return
        buildTabSignature = signature
        box.removeAllViews()
        box.addView(label("Build", 24f, primaryText(), true))
        box.addView(label("Semua repo yang dipantau", 13f, secondaryText()).apply { setPadding(0, dp(2), 0, dp(16)) })
        if (shown.isEmpty()) {
            box.addView(label(
                if (api.configured()) "Belum ada data build. Data muncul setelah repo dimuat."
                else "Hubungkan akun GitHub di tab Akun untuk melihat build.",
                13f, secondaryText()
            ))
            return
        }
        box.addView(sectionTitle("Sedang berjalan", 16f))
        val running = shown.filter { it.run.optString("status") != "completed" }
        if (running.isEmpty()) {
            box.addView(label("Tidak ada build yang berjalan.", 13f, secondaryText()).apply { setPadding(0, dp(4), 0, dp(4)) })
        }
        running.forEach { entry ->
            box.addView(runningRow(entry), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        box.addView(sectionTitle("Riwayat", 16f).apply { setPadding(0, dp(20), 0, dp(4)) })
        shown.forEach { entry -> box.addView(historyRow(entry)) }
    }

    private fun runningRow(entry: BuildEntry): View {
        val id = entry.run.optLong("id")
        val name = entry.run.optString("name", "Workflow")
        val box = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = cardBackground()
            isClickable = true
            isFocusable = true
            setOnClickListener { showGithubRunJobs(id, name, entry.slug) }
        }
        val head = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label(name, 15f, primaryText(), true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val pill = newPill()
        applyPill(pill, "Berjalan", "acc")
        head.addView(pill)
        box.addView(head)
        box.addView(label("${api.displayNameForSlug(entry.slug)} · ${entry.run.optString("head_branch")} · ketuk untuk progres", 12f, secondaryText()).apply {
            setPadding(0, dp(4), 0, 0)
        })
        return box
    }

    private fun historyRow(entry: BuildEntry): View {
        val run = entry.run
        val id = run.optLong("id")
        val name = run.optString("name", "Workflow")
        val status = run.optString("status")
        val conclusion = run.optString("conclusion")
        val state = if (status == "completed") conclusion.ifBlank { "completed" } else status
        val duration = api.formatDuration(
            run.optString("run_started_at", run.optString("created_at")),
            run.optString("updated_at").takeIf { status == "completed" }.orEmpty()
        )
        val dotColor = when {
            status != "completed" -> Color.rgb(26, 115, 232)
            conclusion == "success" -> Color.rgb(30, 107, 48)
            conclusion == "failure" || conclusion == "timed_out" -> Color.rgb(197, 34, 31)
            else -> Color.rgb(150, 150, 150)
        }
        val number = run.optInt("run_number")
        val title = if (number > 0) "$name #$number" else name
        val meta = "${api.displayNameForSlug(entry.slug)} · $state · $duration · ${api.formatTimestamp(run.optString("created_at"))}"
        val trailing: View? = if (status == "completed" && conclusion == "success") {
            linkText("Install") {
                Toast.makeText(host, "Menyiapkan APK…", Toast.LENGTH_SHORT).show()
                monitor.downloadRunArtifacts(entry.slug, id, true)
            }
        } else null
        val wrapper = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        wrapper.addView(divider())
        wrapper.addView(compactRow(dotColor, title, meta, trailing) { showGithubRunJobs(id, name, entry.slug) })
        return wrapper
    }

    // ================================================================ tab Akun

    fun buildAccountTab(): View {
        val scroll = ScrollView(host)
        val page = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        scroll.addView(page)
        accountBox = page
        renderAccountTab()
        return scroll
    }

    private fun saveAccount(owner: String, token: String) {
        if (owner.isBlank() || token.isBlank()) {
            Toast.makeText(host, "Username dan token wajib diisi", Toast.LENGTH_LONG).show()
            return
        }
        try {
            api.saveAccount(owner, token)
            Toast.makeText(host, "Akun GitHub tersimpan", Toast.LENGTH_SHORT).show()
            monitor.start()
            updateStatusText()
            renderGithubPage()
            refreshBuildTab(true)
            renderAccountTab()
        } catch (e: Exception) {
            Toast.makeText(host, "Gagal menyimpan token: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleRow(title: String, description: String, key: String): View {
        val row = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val texts = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 15f, primaryText(), true))
        texts.addView(label(description, 12f, secondaryText()))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        val switch = SwitchCompat(host).apply {
            isChecked = api.option(key)
            setOnCheckedChangeListener { _, on -> api.setOption(key, on) }
        }
        row.addView(switch)
        return row
    }

    fun renderAccountTab() {
        val box = accountBox ?: return
        box.removeAllViews()
        box.addView(label("Akun & pengaturan", 24f, primaryText(), true))

        val form = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = cardBackground()
        }
        form.addView(label("Hubungkan GitHub", 16f, primaryText(), true))
        form.addView(label("Username / organisasi", 12f, secondaryText(), true).apply { setPadding(0, dp(12), 0, dp(4)) })
        val ownerField = EditText(host).apply { hint = "nama-anda"; setSingleLine(true); setText(api.owner()) }
        styleField(ownerField)
        form.addView(ownerField, LinearLayout.LayoutParams(MATCH, WRAP))
        form.addView(label("Personal Access Token", 12f, secondaryText(), true).apply { setPadding(0, dp(12), 0, dp(4)) })
        val tokenField = EditText(host).apply {
            hint = "Token GitHub"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(api.token())
        }
        styleField(tokenField)
        form.addView(tokenField, LinearLayout.LayoutParams(MATCH, WRAP))
        form.addView(label("Izin token: Contents (baca & tulis) dan Actions (baca). Disimpan terenkripsi dengan Android Keystore.", 12f, secondaryText()).apply {
            setPadding(0, dp(8), 0, dp(12))
        })
        val buttons = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(label("Simpan", 15f, onAccent(), true).apply {
            gravity = Gravity.CENTER
            background = pressable(accentColor(), 24, false)
            setPadding(dp(18), dp(13), dp(18), dp(13))
            isClickable = true
            isFocusable = true
            setOnClickListener { saveAccount(ownerField.text.toString().trim(), tokenField.text.toString().trim()) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        buttons.addView(label("Hapus akses", 15f, Color.rgb(197, 34, 31), true).apply {
            gravity = Gravity.CENTER
            background = pressable(cardColor(), 24, true)
            setPadding(dp(18), dp(13), dp(18), dp(13))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                api.clearAccess()
                Toast.makeText(host, "Akses GitHub dihapus", Toast.LENGTH_SHORT).show()
                updateStatusText()
                refreshBuildTab(true)
                renderAccountTab()
            }
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        form.addView(buttons)
        box.addView(form, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        val reposHead = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(4))
        }
        reposHead.addView(label("Repo yang dipantau", 16f, primaryText(), true), LinearLayout.LayoutParams(0, WRAP, 1f))
        reposHead.addView(linkText("+ Tambah") { showAddRepoDialog() })
        box.addView(reposHead)
        val repos = api.customRepos()
        if (repos.isEmpty()) box.addView(label("Belum ada repo.", 13f, secondaryText()))
        repos.forEach { r ->
            val row = LinearLayout(host).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val column = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
            column.addView(label(r.displayName, 15f, primaryText(), true))
            column.addView(label("${r.owner}/${r.repo} · ${r.branch} · ${r.zipName}", 12f, secondaryText()))
            row.addView(column, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(linkText("Ubah") { showEditRepoDialog(r.displayName) })
            row.addView(linkText("Hapus") { confirmRemoveRepo(r.displayName) })
            box.addView(divider())
            box.addView(row)
        }

        box.addView(label("Otomatisasi", 16f, primaryText(), true).apply { setPadding(0, dp(24), 0, dp(4)) })
        box.addView(toggleRow("Unduh artifact otomatis", "APK dan log diunduh setelah build selesai", "opt_auto_download"))
        box.addView(divider())
        box.addView(toggleRow("Tawarkan pasang APK", "Tombol Install muncul di notifikasi hasil build", "opt_offer_install"))
        box.addView(divider())
        box.addView(toggleRow("Pantau di latar belakang", "Notifikasi \"Memantau build GitHub\" menjaga pemantauan tetap hidup", "opt_background_monitor"))

        box.addView(label("Unduhan tersimpan di folder Download/RepoDeck: Builds (artifact), BuildLogs (log build gagal), dan Apk (APK siap pasang).", 12f, secondaryText()).apply {
            setPadding(0, dp(20), 0, 0)
        })
    }

    private fun createRepoCard(displayName: String): RepoCard {
        val slug = api.repositorySlug(displayName)
        val root = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = cardBackground()
        }
        val header = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleColumn = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(label(displayName, 15f, primaryText(), true))
        val info = label("Memuat…", 11f, secondaryText())
        titleColumn.addView(info)
        header.addView(titleColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pill = newPill()
        applyPill(pill, "…", "neutral")
        header.addView(pill, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(8) })
        val chevron = label("⌄", 16f, secondaryText(), true).apply { setPadding(dp(8), 0, 0, 0) }
        chevron.visibility = View.GONE
        header.addView(chevron)
        root.addView(header)

        val quick = linkText("Upload ZIP ke $displayName") { startUploadFor(displayName) }.apply { setPadding(0, dp(8), dp(8), 0) }
        root.addView(quick)

        val body = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(10), 0, 0)
        }
        val stepper = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(10)) }
        body.addView(stepper)
        val upload = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = roundedBackground(accentColor(), dp(12).toFloat())
            setOnClickListener { startUploadFor(displayName) }
        }
        upload.addView(label("Upload ZIP ke $displayName", 14f, onAccent(), true))
        upload.addView(label("${api.ownerFor(slug).ifBlank { "owner" }}/$slug · ${api.branchFor(slug)}", 11f, onAccent()))
        body.addView(upload, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })
        val history = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        body.addView(history)
        val runs = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        body.addView(runs)
        val footer = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (api.isCustom(displayName)) {
            footer.addView(linkText("Ubah") { showEditRepoDialog(displayName) }.apply { setPadding(0, dp(6), dp(8), dp(6)) })
            footer.addView(linkText("Hapus") { confirmRemoveRepo(displayName) })
        }
        footer.addView(View(host), LinearLayout.LayoutParams(0, 1, 1f))
        footer.addView(linkText("Buka di GitHub") {
            try {
                host.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://github.com/${api.ownerFor(slug)}/$slug")))
            } catch (e: Exception) {
                Toast.makeText(host, "Tidak dapat membuka browser", Toast.LENGTH_SHORT).show()
            }
        })
        body.addView(footer, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(body)
        return RepoCard(displayName, slug, root, info, pill, chevron, quick, body, stepper, history, runs)
    }

    private fun renderGithubPage() {
        // Kartu progress/hasil milik repo sebelumnya disembunyikan saat halaman dibangun ulang.
        githubUploadCard?.let { c ->
            if (c.tag != null) { c.visibility = View.GONE; c.tag = null; c.setOnClickListener(null) }
        }
        updateStatusText()
        api.repositories.forEach { refreshCard(it) }
        if (!api.configured()) return
        api.repositories.forEach { loadRepoRuns(it, true); loadHistory(it) }
    }

    private fun selectRepo(displayRepo: String) {
        val previousRepo = githubSelectedRepo
        githubSelectedRepo = displayRepo
        api.prefs.edit().putString("selected_repo", displayRepo).apply()
        githubExpanded = true
        githubUploadCard?.let { c ->
            if (c.tag != null) { c.visibility = View.GONE; c.tag = null; c.setOnClickListener(null) }
        }
        rebuildChips(previousRepo)
        rebuildCards()
        refreshCard(displayRepo)
        if (api.configured()) { loadRepoRuns(displayRepo, false); loadHistory(displayRepo) }
    }

    private fun toggleCard(displayRepo: String) {
        if (githubExpanded && githubSelectedRepo == displayRepo) {
            githubExpanded = false
            api.repositories.forEach { refreshCard(it) }
        } else {
            selectRepo(displayRepo)
        }
    }

    private fun startUploadFor(displayRepo: String) {
        if (!api.configured()) { showGithubAccountDialog(); return }
        pendingUploadRepo = displayRepo
        if (githubSelectedRepo != displayRepo || !githubExpanded) selectRepo(displayRepo)
        host.launchGithubZipPicker()
    }

    // ---------------------------------------------------------------- data kartu

    private fun pillFor(slug: String): Pair<String, String> {
        if (uploadingSlug == slug) return Pair("Mengunggah", "acc")
        val latest = monitor.runsCache[slug]?.optJSONObject(0) ?: return Pair("—", "neutral")
        if (latest.optString("status") != "completed") return Pair("Build berjalan", "acc")
        return when (latest.optString("conclusion")) {
            "success" -> Pair("Build berhasil", "ok")
            "failure", "timed_out" -> Pair("Build gagal", "bad")
            "cancelled" -> Pair("Dibatalkan", "warn")
            else -> Pair("Selesai", "neutral")
        }
    }

    private fun infoLine(slug: String): String {
        val date = historyCache[slug]?.optJSONObject(0)?.optJSONObject("commit")?.optJSONObject("committer")?.optString("date").orEmpty()
        if (date.isNotBlank()) return "Upload terakhir ${api.formatTimestamp(date)}"
        val run = monitor.runsCache[slug]?.optJSONObject(0)
        return if (run != null) "Run terakhir ${api.formatTimestamp(run.optString("created_at"))}" else "Belum ada data"
    }

    /** (langkah aktif 0..3, atau 4 bila semua selesai; true bila build gagal) atau null bila tidak ada aktivitas. */
    private fun stepperState(slug: String): Pair<Int, Boolean>? {
        if (uploadingSlug == slug) return Pair(1, false)
        if (api.prefs.getString("github_auto_build_commit_$slug", "").orEmpty().isNotBlank()) return Pair(2, false)
        if (api.prefs.getLong("github_auto_build_run_$slug", 0L) > 0L) return Pair(3, false)
        val result = monitor.lastResult(slug) ?: return null
        return Pair(4, result.conclusion != "success")
    }

    private fun runsSignature(runs: JSONArray?): String {
        if (runs == null) return "null"
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            val r = runs.optJSONObject(i) ?: continue
            sb.append(r.optLong("id")).append(r.optString("status")).append(r.optString("conclusion")).append(';')
        }
        return sb.toString()
    }

    private fun historySignature(slug: String): String {
        val arr = historyCache[slug] ?: return "null"
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.optJSONObject(i)?.optString("sha").orEmpty()).append(';')
        return sb.toString()
    }

    private fun refreshCard(displayRepo: String) {
        val card = repoCards[displayRepo] ?: return
        val open = githubExpanded && githubSelectedRepo == displayRepo
        val pillInfo = pillFor(card.slug)
        applyPill(card.pill, pillInfo.first, pillInfo.second)
        card.info.text = infoLine(card.slug)
        card.chevron.text = if (open) "⌃" else "⌄"
        card.body.visibility = if (open) View.VISIBLE else View.GONE
        card.quick.visibility = if (open) View.GONE else View.VISIBLE
        if (!open) return
        val runs = monitor.runsCache[card.slug]
        val signature = "${runsSignature(runs)}|${historySignature(card.slug)}|${stepperState(card.slug)}|$githubHistoryExpanded|${loadFailed["h:${card.slug}"]}|${loadFailed["r:${card.slug}"]}"
        if (signature == card.signature) return
        card.signature = signature
        renderStepper(card)
        renderHistory(card)
        renderRuns(card, runs)
    }

    private fun loadRepoRuns(displayRepo: String, silent: Boolean) {
        if (!repoCards.containsKey(displayRepo)) return
        if (!api.configured()) return
        if (!runsInFlight.add(displayRepo)) return
        val repoSlug = api.repositorySlug(displayRepo)
        val owner = api.ownerFor(repoSlug)
        executor.execute {
            try {
                val runs = JSONObject(api.request("/repos/$owner/$repoSlug/actions/runs?per_page=20"))
                    .optJSONArray("workflow_runs") ?: JSONArray()
                monitor.handleRuns(repoSlug, runs)
                loadFailed.remove("r:$repoSlug")
                main.post {
                    runsInFlight.remove(displayRepo)
                    if (!host.isGithubSection()) return@post
                    try {
                        updateStatusText()
                        refreshCard(displayRepo)
                        refreshChips()
                        refreshBuildTab()
                        if (displayRepo == githubSelectedRepo) {
                            maybeOpenUploadedBuildMonitor(displayRepo, repoSlug, runs)
                            showStoredResultCard(repoSlug)
                        }
                    } catch (e: Exception) {
                        CrashLogger.record(host, e, "render repo card")
                    }
                }
            } catch (e: Exception) {
                loadFailed["r:$repoSlug"] = failureText(e)
                main.post {
                    runsInFlight.remove(displayRepo)
                    monitor.reportError(e)
                    if (host.isGithubSection()) refreshCard(displayRepo)
                    if (host.isGithubSection() && !silent && e !is GithubRateLimitException) {
                        Toast.makeText(host, "Gagal memuat Actions ($displayRepo): ${e.message ?: "periksa koneksi dan izin token"}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun failureText(e: Exception): String =
        (e.message ?: "periksa koneksi dan izin token").lineSequence().first().take(90)

    /** Baris "gagal memuat" dengan tombol coba lagi, menggantikan teks "Memuat…" yang menggantung. */
    private fun failureRow(parent: LinearLayout, message: String, onRetry: () -> Unit) {
        parent.addView(label("Gagal memuat: $message", 12f, Color.rgb(205, 65, 65)))
        parent.addView(linkText("Coba lagi") { onRetry() }.apply { setPadding(0, dp(6), dp(8), dp(6)) })
    }

    private fun loadHistory(displayRepo: String) {
        if (!api.configured()) return
        val slug = api.repositorySlug(displayRepo)
        val owner = api.ownerFor(slug)
        val name = api.canonicalZipName(displayRepo)
        executor.execute {
            try {
                val arr = JSONArray(api.request("/repos/$owner/$slug/commits?path=${Uri.encode(name)}&sha=${Uri.encode(api.branchFor(slug))}&per_page=5"))
                historyCache[slug] = arr
                loadFailed.remove("h:$slug")
                main.post { if (host.isGithubSection()) refreshCard(displayRepo) }
            } catch (e: Exception) {
                loadFailed["h:$slug"] = failureText(e)
                main.post {
                    monitor.reportError(e)
                    if (host.isGithubSection()) refreshCard(displayRepo)
                }
            }
        }
    }

    // ---------------------------------------------------------------- render isi kartu

    private fun renderStepper(card: RepoCard) {
        card.stepper.removeAllViews()
        val state = stepperState(card.slug)
        if (state == null) { card.stepper.visibility = View.GONE; return }
        card.stepper.visibility = View.VISIBLE
        val current = state.first
        val failed = state.second
        listOf("Dipilih", "Diunggah", "Commit", "Build").forEachIndexed { i, text ->
            if (i > 0) {
                card.stepper.addView(View(host).apply { setBackgroundColor(Color.argb(60, 128, 128, 128)) },
                    LinearLayout.LayoutParams(dp(14), dp(1)).apply { topMargin = dp(11) })
            }
            val column = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val done = i < current
            val isCurrent = i == current
            val bad = current >= 4 && failed && i == 3
            val colors = when {
                bad -> Pair(Color.rgb(253, 226, 226), Color.rgb(153, 27, 27))
                done -> Pair(Color.rgb(223, 245, 230), Color.rgb(24, 94, 52))
                isCurrent -> Pair(Color.rgb(219, 234, 254), Color.rgb(30, 64, 175))
                else -> Pair(cardColor(), secondaryText())
            }
            val circle = TextView(host).apply {
                gravity = Gravity.CENTER
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                this.text = when {
                    bad -> "!"
                    done -> "✓"
                    else -> (i + 1).toString()
                }
                setTextColor(colors.second)
                background = roundedBackground(colors.first, dp(11).toFloat())
            }
            column.addView(circle, LinearLayout.LayoutParams(dp(22), dp(22)))
            column.addView(label(text, 10f, secondaryText()).apply { gravity = Gravity.CENTER })
            card.stepper.addView(column, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun renderHistory(card: RepoCard) {
        card.history.removeAllViews()
        card.history.addView(label("Riwayat upload", 13f, primaryText(), true).apply { setPadding(0, 0, 0, dp(2)) })
        val arr = historyCache[card.slug]
        if (arr == null) {
            val failure = loadFailed["h:${card.slug}"]
            if (failure != null) {
                failureRow(card.history, failure) {
                    loadFailed.remove("h:${card.slug}")
                    refreshCard(card.displayName)
                    loadHistory(card.displayName)
                }
            } else {
                card.history.addView(label("Memuat riwayat…", 12f, secondaryText()))
            }
            return
        }
        if (arr.length() == 0) {
            card.history.addView(label("Belum ada upload untuk ${api.canonicalZipName(card.displayName)}.", 12f, secondaryText()))
            return
        }
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val sha = item.optString("sha")
            val commit = item.optJSONObject("commit")
            val message = commit?.optString("message").orEmpty().lineSequence().first().trim().take(70)
            val date = commit?.optJSONObject("committer")?.optString("date").orEmpty()
            val dateText = api.formatTimestamp(date)
            val trailing: View = if (i == 0) {
                newPill().also { applyPill(it, "Aktif", "acc") }
            } else {
                linkText("Pulihkan") { confirmRestore(card.displayName, sha, dateText) }
            }
            card.history.addView(divider())
            card.history.addView(compactRow(null, message.ifBlank { "Commit ${sha.take(7)}" }, "$dateText · ${sha.take(7)}", trailing, null))
        }
    }

    private fun renderRuns(card: RepoCard, runs: JSONArray?) {
        card.runs.removeAllViews()
        card.runs.addView(label("Workflow runs", 13f, primaryText(), true).apply { setPadding(0, dp(12), 0, dp(2)) })
        if (runs == null) {
            val failure = loadFailed["r:${card.slug}"]
            if (failure != null) {
                failureRow(card.runs, failure) {
                    loadFailed.remove("r:${card.slug}")
                    refreshCard(card.displayName)
                    loadRepoRuns(card.displayName, false)
                }
            } else {
                card.runs.addView(label("Memuat workflow…", 12f, secondaryText()))
            }
            return
        }
        if (runs.length() == 0) {
            card.runs.addView(label("Belum ada workflow run.", 12f, secondaryText()))
            return
        }
        var running = 0
        var success = 0
        var failed = 0
        for (i in 0 until runs.length()) {
            val item = runs.optJSONObject(i) ?: continue
            when {
                item.optString("status") != "completed" -> running++
                item.optString("conclusion") == "success" -> success++
                item.optString("conclusion") in listOf("failure", "cancelled", "timed_out") -> failed++
            }
        }
        card.runs.addView(label("$running berjalan  ·  $success berhasil  ·  $failed gagal  ·  ${runs.length()} terakhir", 11f, secondaryText()))
        val wrappers = mutableListOf<View>()
        for (i in 0 until runs.length()) {
            val run = runs.optJSONObject(i) ?: continue
            val id = run.optLong("id")
            val name = run.optString("name", "Workflow")
            val status = run.optString("status")
            val conclusion = run.optString("conclusion")
            val state = if (status == "completed") conclusion.ifBlank { "completed" } else status
            val duration = api.formatDuration(
                run.optString("run_started_at", run.optString("created_at")),
                run.optString("updated_at").takeIf { status == "completed" }.orEmpty()
            )
            val event = run.optString("event").replaceFirstChar { it.uppercase(Locale.getDefault()) }
            val meta = "$state  ·  ${run.optString("head_branch")}  ·  ${run.optString("head_sha").take(7)}\n" +
                "${api.formatTimestamp(run.optString("created_at"))}  ·  $duration  ·  $event"
            val dotColor = when {
                status != "completed" -> Color.rgb(26, 115, 232)
                conclusion == "success" -> Color.rgb(34, 150, 83)
                conclusion in listOf("failure", "timed_out") -> Color.rgb(205, 65, 65)
                else -> Color.rgb(150, 150, 150)
            }
            val trailing: View? = if (status == "completed" && conclusion == "success") {
                LinearLayout(host).apply {
                    orientation = LinearLayout.HORIZONTAL
                    addView(linkText("Unduh") {
                        Toast.makeText(host, "Mengunduh artifact…", Toast.LENGTH_SHORT).show()
                        monitor.downloadRunArtifacts(card.slug, id)
                    })
                    addView(linkText("Install") {
                        Toast.makeText(host, "Menyiapkan APK…", Toast.LENGTH_SHORT).show()
                        monitor.downloadRunArtifacts(card.slug, id, true)
                    })
                }
            } else null
            val wrapper = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
            wrapper.addView(divider())
            wrapper.addView(compactRow(dotColor, name, meta, trailing) { showGithubRunJobs(id, name, card.slug) })
            wrapper.visibility = if (githubHistoryExpanded || wrappers.size < 3) View.VISIBLE else View.GONE
            wrappers.add(wrapper)
            card.runs.addView(wrapper)
        }
        if (wrappers.size > 3) {
            card.runs.addView(linkText(
                if (githubHistoryExpanded) "Sembunyikan riwayat  ⌃" else "Lihat ${wrappers.size - 3} riwayat lainnya  ⌄"
            ) {
                githubHistoryExpanded = !githubHistoryExpanded
                repoCards.values.forEach { it.signature = "" }
                refreshCard(card.displayName)
            }.apply { gravity = Gravity.CENTER })
        }
    }

    // ---------------------------------------------------------------- konfirmasi upload

    private class UploadCheck(
        val sizeText: String,
        val repoText: String,
        val contentText: String,
        val warnings: List<String>,
        val oks: List<String>,
        val identity: String?
    )

    private fun identityOf(info: ZipInfo?): String? =
        if (info == null || (info.rootName == null && info.appId == null)) null
        else "${info.rootName.orEmpty()}|${info.appId.orEmpty()}"

    private fun identityLabel(identity: String): String {
        val parts = identity.split("|")
        return parts.getOrNull(0).orEmpty().ifBlank { parts.getOrNull(1).orEmpty() }.ifBlank { "tidak diketahui" }
    }

    private fun identityMismatch(a: String, b: String): Boolean {
        val pa = a.split("|")
        val pb = b.split("|")
        val rootA = pa.getOrNull(0).orEmpty(); val rootB = pb.getOrNull(0).orEmpty()
        val appA = pa.getOrNull(1).orEmpty(); val appB = pb.getOrNull(1).orEmpty()
        return (rootA.isNotBlank() && rootB.isNotBlank() && rootA != rootB) ||
            (appA.isNotBlank() && appB.isNotBlank() && appA != appB)
    }

    /** Repo lain yang namanya muncul di nama file yang dipilih (dan bukan nama repo tujuan). */
    private fun otherRepoHint(sourceName: String, displayRepo: String): String? {
        val lower = sourceName.lowercase(Locale.ROOT)
        fun tokens(repo: String) = listOf(
            repo.lowercase(Locale.ROOT),
            api.repositorySlug(repo).lowercase(Locale.ROOT),
            api.canonicalZipName(repo).lowercase(Locale.ROOT).removeSuffix(".zip")
        ).filter { it.length >= 4 }
        if (tokens(displayRepo).any { lower.contains(it) }) return null
        return api.repositories.firstOrNull { it != displayRepo && tokens(it).any { token -> lower.contains(token) } }
    }

    /** Dijalankan di executor: membandingkan ZIP yang dipilih dengan isi repository. */
    private fun checkZipUpload(uri: Uri, displayRepo: String, sourceName: String): UploadCheck {
        val slug = api.repositorySlug(displayRepo)
        val owner = api.ownerFor(slug)
        val target = api.canonicalZipName(displayRepo)
        val warnings = mutableListOf<String>()
        val oks = mutableListOf<String>()

        val zipSize = GithubUploadTools.queryZipSize(host, uri)
        val modified = GithubUploadTools.queryLastModified(host, uri)
        val info = try { GithubUploadTools.inspectZip(host, uri) } catch (e: Exception) { null }
        val blob = if (zipSize > 0L && zipSize <= 70L * 1024L * 1024L) GithubUploadTools.gitBlobSha(host, uri, zipSize) else null

        var remoteFound = false
        var remoteSize = -1L
        var remoteSha = ""
        try {
            val remote = JSONObject(api.request("/repos/$owner/$slug/contents/${Uri.encode(target)}?ref=${Uri.encode(api.branchFor(slug))}"))
            remoteFound = true
            remoteSize = remote.optLong("size", -1L)
            remoteSha = remote.optString("sha")
        } catch (e: Exception) {
            if (e.message?.contains("API 404") != true) {
                warnings.add("Tidak dapat membandingkan dengan repo: ${e.message ?: "kesalahan jaringan"}")
            }
        }
        var remoteDate = 0L
        try {
            val arr = JSONArray(api.request("/repos/$owner/$slug/commits?path=${Uri.encode(target)}&sha=${Uri.encode(api.branchFor(slug))}&per_page=1"))
            remoteDate = parseIsoMs(arr.optJSONObject(0)?.optJSONObject("commit")?.optJSONObject("committer")?.optString("date").orEmpty())
        } catch (_: Exception) {
        }

        // --- teks ringkasan
        val sizeText = (if (zipSize >= 0L) fmtMb(zipSize) else "ukuran tidak diketahui") + " · " +
            (if (modified != null) fmtDateMs(modified) else "tanggal tidak tersedia")
        val repoText = if (remoteFound) {
            target + (if (remoteSize >= 0L) " · ${fmtMb(remoteSize)}" else "") + (if (remoteDate > 0L) " · ${fmtDateMs(remoteDate)}" else "")
        } else "Belum ada (file baru)"
        val identity = identityOf(info)
        val contentText = when {
            info == null -> "Tidak dapat dibaca"
            identity != null -> "${info.fileCount} file · proyek ${identityLabel(identity)}"
            else -> "${info.fileCount} file · proyek tidak diketahui"
        }

        // --- peringatan
        otherRepoHint(sourceName, displayRepo)?.let { other ->
            warnings.add("Nama file mengarah ke repo $other, bukan $displayRepo.")
        }
        if (info == null) {
            warnings.add("ZIP tidak dapat dibaca. File mungkin rusak atau bukan ZIP.")
        } else if (identity == null && info.fileCount > 0) {
            warnings.add("Tidak ditemukan file proyek Gradle (settings.gradle) di dalam ZIP.")
        }
        if (identity != null) {
            val stored = api.prefs.getString("github_zip_identity_$slug", null)
            val crossMatch = api.repositories.firstOrNull { other ->
                if (other == displayRepo) return@firstOrNull false
                val otherStored = api.prefs.getString("github_zip_identity_${api.repositorySlug(other)}", null)
                otherStored != null && !identityMismatch(identity, otherStored) &&
                    (stored == null || identityMismatch(identity, stored))
            }
            when {
                crossMatch != null -> warnings.add("Isi ZIP cocok dengan repo $crossMatch, bukan $displayRepo.")
                stored != null && identityMismatch(identity, stored) ->
                    warnings.add("Nama proyek di ZIP (${identityLabel(identity)}) berbeda dari upload sebelumnya (${identityLabel(stored)}).")
                stored != null -> oks.add("Nama proyek cocok dengan upload sebelumnya.")
                else -> oks.add("Belum ada pembanding isi untuk repo ini. Nama proyek dicatat setelah upload berhasil.")
            }
        }
        if (modified != null && remoteDate > 0L && modified < remoteDate) {
            warnings.add("ZIP ini lebih lama (diubah ${fmtDateMs(modified)}) dari versi di repo (commit ${fmtDateMs(remoteDate)}).")
        }
        if (zipSize > 0L && remoteSize > 0L) {
            val change = ((zipSize - remoteSize) * 100.0 / remoteSize).toInt()
            if (kotlin.math.abs(change) > 50) warnings.add("Ukuran berubah $change% dari versi di repo.")
        }
        if (blob != null && remoteSha.isNotBlank() && blob == remoteSha) {
            warnings.add("File sama persis dengan versi di repo. Upload tidak akan mengubah isinya.")
        }
        return UploadCheck(sizeText, repoText, contentText, warnings, oks, identity)
    }

    private fun noteBox(text: String, warning: Boolean): TextView = TextView(host).apply {
        this.text = text
        textSize = 12f
        setTextColor(if (warning) Color.rgb(120, 53, 15) else Color.rgb(24, 94, 52))
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = roundedBackground(if (warning) Color.rgb(254, 243, 199) else Color.rgb(223, 245, 230), dp(8).toFloat())
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    fun confirmGithubZipUpload(uri: Uri) {
        if (!api.configured()) { showGithubAccountDialog(); return }
        val displayRepo = pendingUploadRepo ?: githubSelectedRepo
        pendingUploadRepo = null
        val repoSlug = api.repositorySlug(displayRepo)
        val sourceName = host.queryDisplayName(uri).substringAfterLast('/').ifBlank { "upload.zip" }
        if (!sourceName.lowercase(Locale.ROOT).endsWith(".zip")) {
            Toast.makeText(host, "Pilih file dengan ekstensi .zip", Toast.LENGTH_LONG).show()
            return
        }
        val targetName = api.canonicalZipName(displayRepo)
        val details = LinearLayout(host).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        fun addRow(caption: String, value: String): TextView {
            details.addView(label(caption, 11f, secondaryText(), true).apply { setPadding(0, dp(8), 0, dp(2)) })
            val v = label(value, 14f, primaryText())
            v.setPadding(0, 0, 0, dp(2))
            details.addView(v)
            return v
        }
        addRow("TUJUAN", "${api.ownerFor(repoSlug)}/$repoSlug · ${api.branchFor(repoSlug)}")
        addRow("FILE DIPILIH", "$sourceName  →  $targetName")
        val sizeValue = addRow("UKURAN · DIUBAH", "Memeriksa…")
        val repoValue = addRow("DI REPO SEKARANG", "Memeriksa…")
        val contentValue = addRow("ISI ZIP", "Memeriksa…")
        val notes = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL }
        details.addView(notes)
        details.addView(label("Jika file tujuan sudah ada, versi sebelumnya diganti melalui commit baru dan tetap bisa dipulihkan dari Riwayat upload.", 11f, secondaryText()).apply {
            setPadding(0, dp(12), 0, dp(4))
        })
        // Tombol aksi memakai baris sendiri di dalam view dialog (lihat catatan tema Android 10 sebelumnya).
        val actions = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(4))
        }
        val cancel = TextView(host).apply {
            text = "Batal"
            textSize = 14f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(primaryText())
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = pressable(cardColor(), 14, true)
        }
        val confirm = TextView(host).apply {
            text = "Memeriksa…"
            textSize = 14f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = pressable(Color.rgb(26, 115, 232), 14, false)
            isEnabled = false
            alpha = 0.5f
        }
        actions.addView(cancel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) })
        actions.addView(confirm)
        details.addView(actions, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val dialog = AlertDialog.Builder(host)
            .setTitle("Konfirmasi upload")
            .setView(ScrollView(host).apply { addView(details) })
            .create()
        dialog.setOnShowListener {
            dialog.findViewById<TextView>(android.R.id.title)?.setTextColor(primaryText())
            dialog.findViewById<TextView>(android.R.id.title)?.setTypeface(null, Typeface.BOLD)
        }
        var identity: String? = null
        cancel.setOnClickListener { dialog.dismiss() }
        confirm.setOnClickListener {
            dialog.dismiss()
            uploadGithubZip(uri, displayRepo, sourceName, identity)
        }
        dialog.showStyled()

        fun applyCheck(c: UploadCheck) {
            identity = c.identity
            sizeValue.text = c.sizeText
            repoValue.text = c.repoText
            contentValue.text = c.contentText
            notes.removeAllViews()
            c.warnings.forEach { notes.addView(noteBox(it, true)) }
            c.oks.forEach { notes.addView(noteBox(it, false)) }
            confirm.isEnabled = true
            confirm.alpha = 1f
            if (c.warnings.isNotEmpty()) {
                // Ada peringatan: "Batal" menjadi aksi utama, upload butuh keputusan sadar.
                confirm.text = "Tetap upload"
                confirm.setTextColor(primaryText())
                confirm.background = pressable(cardColor(), 14, true)
                cancel.setTextColor(Color.WHITE)
                cancel.background = pressable(Color.rgb(26, 115, 232), 14, false)
            } else {
                confirm.text = "Upload"
            }
        }
        executor.execute {
            val check = try {
                checkZipUpload(uri, displayRepo, sourceName)
            } catch (e: Exception) {
                UploadCheck("—", "—", "—", listOf("Pemeriksaan gagal: ${e.message ?: "kesalahan"}. Upload tetap bisa dilanjutkan."), emptyList(), null)
            }
            main.post { applyCheck(check) }
        }
    }

    // ---------------------------------------------------------------- upload & pulihkan

    /** Dipanggil di executor. Mengembalikan sha commit; bila respons terputus, memeriksa apakah commit sempat masuk. */
    private fun sendRepoFile(path: String, body: JSONObject, repoSlug: String, name: String, verb: String): String {
        val bodyBytes = body.toString().toByteArray(Charsets.UTF_8)
        val startedAt = System.currentTimeMillis()
        main.post {
            showGithubUploadProgress(name, true)
            githubUploadTitle?.text = "$verb $name"
            githubUploadDetail?.text = "Mengirim data ke GitHub…"
        }
        return try {
            val response = api.requestWithProgress(path, bodyBytes) { percent, sent, total ->
                main.post {
                    updateGithubUploadProgress(percent, sent, total)
                    if (percent >= 100) githubUploadTitle?.text = "Menunggu respons GitHub…"
                }
            }
            JSONObject(response).optJSONObject("commit")?.optString("sha").orEmpty()
        } catch (e: java.io.IOException) {
            findLandedCommit(repoSlug, name, startedAt) ?: throw e
        }
    }

    private fun findLandedCommit(repoSlug: String, name: String, startedAt: Long): String? = try {
        val arr = JSONArray(api.request("/repos/${api.ownerFor(repoSlug)}/$repoSlug/commits?path=${Uri.encode(name)}&sha=${Uri.encode(api.branchFor(repoSlug))}&per_page=1"))
        val first = arr.optJSONObject(0)
        val at = parseIsoMs(first?.optJSONObject("commit")?.optJSONObject("committer")?.optString("date").orEmpty())
        if (first != null && at >= startedAt - 5_000L) first.optString("sha") else null
    } catch (_: Exception) {
        null
    }

    private fun finishSend(displayRepo: String, repoSlug: String, name: String, bytesSize: Long, doneTitle: String, toast: String, commitSha: String) {
        monitor.trackUploadedCommit(repoSlug, commitSha)
        main.post {
            uploadingSlug = null
            refreshChips()
            updateGithubUploadProgress(100, bytesSize, bytesSize, "Selesai · menunggu GitHub Actions…")
            githubUploadTitle?.text = doneTitle
            githubUploadPercent?.text = "✓"
            Toast.makeText(host, toast, Toast.LENGTH_LONG).show()
            monitor.start()
            historyCache.remove(repoSlug)
            loadHistory(displayRepo)
            if (host.isGithubSection()) loadRepoRuns(displayRepo, true)
            repoCards.values.forEach { it.signature = "" }
            refreshCard(displayRepo)
        }
    }

    private fun failSend(displayRepo: String, name: String, e: Exception, title: String) {
        main.post {
            uploadingSlug = null
            refreshChips()
            monitor.reportError(e)
            showGithubUploadProgress(name, true)
            githubUploadTitle?.text = title
            updateGithubUploadProgress(0, 0, 0, e.message ?: "Terjadi kesalahan")
            Toast.makeText(host, "$title: ${e.message}", Toast.LENGTH_LONG).show()
            repoCards.values.forEach { it.signature = "" }
            refreshCard(displayRepo)
        }
    }

    private fun uploadGithubZip(uri: Uri, displayRepo: String, sourceName: String, identity: String?) {
        if (!api.configured()) { showGithubAccountDialog(); return }
        val repoSlug = api.repositorySlug(displayRepo)
        val owner = api.ownerFor(repoSlug)
        githubActiveUploadRepoSlug = repoSlug
        uploadingSlug = repoSlug
        api.prefs.edit().remove(monitor.pendingProgressDismissKey(repoSlug)).apply()
        main.post {
            refreshChips()
            showGithubUploadProgress("file ZIP", true)
            githubUploadDetail?.text = "Membaca file dan menyiapkan koneksi…"
            repoCards.values.forEach { it.signature = "" }
            refreshCard(displayRepo)
        }
        executor.execute {
            var name = "upload.zip"
            try {
                name = api.canonicalZipName(displayRepo)
                main.post { githubUploadTitle?.text = "Mengunggah sebagai $name" }
                val bytes = host.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("File tidak dapat dibaca")
                if (bytes.size > 70 * 1024 * 1024) throw IllegalArgumentException("Ukuran ZIP terlalu besar untuk upload melalui GitHub Contents API (batas aplikasi 70 MB)")
                val path = "/repos/$owner/$repoSlug/contents/${Uri.encode(name)}"
                val existingSha = try {
                    JSONObject(api.request("$path?ref=${Uri.encode(api.branchFor(repoSlug))}")).optString("sha")
                } catch (e: Exception) {
                    if (e.message?.contains("API 404") == true) "" else throw e
                }
                val message = "Upload $name dari $sourceName (${fmtMb(bytes.size.toLong())}) via RepoDeck"
                val body = JSONObject().put("message", message).put("branch", api.branchFor(repoSlug))
                    .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
                if (existingSha.isNotBlank()) body.put("sha", existingSha)
                val commitSha = sendRepoFile(path, body, repoSlug, name, "Mengunggah")
                if (!identity.isNullOrBlank()) api.prefs.edit().putString("github_zip_identity_$repoSlug", identity).apply()
                finishSend(
                    displayRepo, repoSlug, name, bytes.size.toLong(),
                    "Upload berhasil · menunggu build",
                    "$name berhasil di-upload ke $displayRepo/main. Menunggu GitHub Actions…", commitSha
                )
            } catch (e: Exception) {
                failSend(displayRepo, name, e, "Upload gagal")
            }
        }
    }

    private fun confirmRestore(displayRepo: String, commitSha: String, dateText: String) {
        val name = api.canonicalZipName(displayRepo)
        AlertDialog.Builder(host)
            .setTitle("Pulihkan versi lama?")
            .setMessage("$name di $displayRepo/main akan diganti dengan versi commit ${commitSha.take(7)} ($dateText) melalui commit baru, lalu build baru berjalan.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Pulihkan") { _, _ -> restoreGithubVersion(displayRepo, commitSha) }
            .showStyled()
    }

    private fun restoreGithubVersion(displayRepo: String, commitSha: String) {
        if (!api.configured()) { showGithubAccountDialog(); return }
        val repoSlug = api.repositorySlug(displayRepo)
        val owner = api.ownerFor(repoSlug)
        githubActiveUploadRepoSlug = repoSlug
        uploadingSlug = repoSlug
        api.prefs.edit().remove(monitor.pendingProgressDismissKey(repoSlug)).apply()
        main.post {
            refreshChips()
            showGithubUploadProgress("versi lama", true)
            githubUploadTitle?.text = "Memulihkan versi ${commitSha.take(7)}"
            githubUploadDetail?.text = "Mengambil isi versi lama dari GitHub…"
            repoCards.values.forEach { it.signature = "" }
            refreshCard(displayRepo)
        }
        executor.execute {
            val name = api.canonicalZipName(displayRepo)
            try {
                val path = "/repos/$owner/$repoSlug/contents/${Uri.encode(name)}"
                val old = JSONObject(api.request("$path?ref=$commitSha"))
                if (old.optLong("size", 0L) > 25L * 1024L * 1024L) {
                    throw IllegalStateException("Versi ini terlalu besar untuk dipulihkan dari aplikasi. Pulihkan lewat GitHub.")
                }
                val blob = JSONObject(api.request("/repos/$owner/$repoSlug/git/blobs/${old.optString("sha")}"))
                val content = blob.optString("content").replace("\n", "").replace("\r", "")
                if (content.isBlank()) throw IllegalStateException("Isi versi lama tidak dapat dibaca")
                val currentSha = JSONObject(api.request("$path?ref=${Uri.encode(api.branchFor(repoSlug))}")).optString("sha")
                val body = JSONObject()
                    .put("message", "Pulihkan $name ke versi ${commitSha.take(7)} via RepoDeck")
                    .put("branch", api.branchFor(repoSlug))
                    .put("content", content)
                if (currentSha.isNotBlank()) body.put("sha", currentSha)
                val newSha = sendRepoFile(path, body, repoSlug, name, "Memulihkan")
                finishSend(
                    displayRepo, repoSlug, name, content.length.toLong() * 3L / 4L,
                    "Pemulihan berhasil · menunggu build",
                    "$name dipulihkan ke versi ${commitSha.take(7)}. Menunggu GitHub Actions…", newSha
                )
            } catch (e: Exception) {
                failSend(displayRepo, name, e, "Pemulihan gagal")
            }
        }
    }


    // ================================================================ tambah / ubah / hapus repository

    private fun dialogActions(cancelLabel: String, confirmLabel: String): Triple<LinearLayout, TextView, TextView> {
        val actions = LinearLayout(host).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(4))
        }
        val cancel = TextView(host).apply {
            text = cancelLabel
            textSize = 14f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(primaryText())
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = pressable(cardColor(), 14, true)
        }
        val confirm = TextView(host).apply {
            text = confirmLabel
            textSize = 14f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = pressable(Color.rgb(26, 115, 232), 14, false)
        }
        actions.addView(cancel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) })
        actions.addView(confirm)
        return Triple(actions, cancel, confirm)
    }

    private fun formBox(): LinearLayout = LinearLayout(host).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), dp(8))
    }

    private fun addField(box: LinearLayout, hint: String, value: String = "", uri: Boolean = false): EditText {
        val field = EditText(host).apply {
            this.hint = hint
            setSingleLine(true)
            if (uri) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(value)
        }
        styleField(field)
        box.addView(field, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) })
        return field
    }

    private fun rebuildCards() {
        val box = githubCardsBox ?: return
        box.removeAllViews()
        repoCards.clear()
        if (githubSelectedRepo.isBlank() || !api.repositories.contains(githubSelectedRepo)) {
            githubSelectedRepo = api.repositories.firstOrNull().orEmpty()
        }
        if (githubSelectedRepo.isBlank()) {
            box.addView(emptyReposCard())
            return
        }
        val card = createRepoCard(githubSelectedRepo)
        repoCards[githubSelectedRepo] = card
        box.addView(card.root, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private class NewRepoInfo(val repo: CustomRepo, val note: String)

    /** Dijalankan di executor: memastikan repository dapat diakses, lalu menentukan branch default dan nama file ZIP. */
    private fun inspectNewRepo(owner: String, repo: String, label: String): NewRepoInfo {
        val meta = try {
            JSONObject(api.request("/repos/$owner/$repo"))
        } catch (e: GithubRateLimitException) {
            throw e
        } catch (e: Exception) {
            if (e.message?.contains("API 404") == true) {
                throw IllegalStateException("Repository tidak ditemukan atau token tidak punya akses ke $owner/$repo.")
            }
            throw e
        }
        val realOwner = meta.optJSONObject("owner")?.optString("login").orEmpty().ifBlank { owner }
        val realRepo = meta.optString("name").ifBlank { repo }
        val branch = meta.optString("default_branch").ifBlank { "main" }
        val canPush = meta.optJSONObject("permissions")?.optBoolean("push", true) ?: true
        if (!canPush) throw IllegalStateException("Token tidak punya izin menulis ke $realOwner/$realRepo.")

        val zips = mutableListOf<String>()
        try {
            val arr = JSONArray(api.request("/repos/$realOwner/$realRepo/contents?ref=${Uri.encode(branch)}"))
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name")
                if (item.optString("type") == "file" && name.endsWith(".zip", ignoreCase = true)) zips.add(name)
            }
        } catch (e: GithubRateLimitException) {
            throw e
        } catch (_: Exception) {
            // Repository kosong atau daftar tidak dapat dibaca: pakai nama bawaan.
        }
        val zipName = when {
            zips.size == 1 -> zips[0]
            zips.size > 1 -> zips.firstOrNull { it.equals("$realRepo.zip", ignoreCase = true) } ?: zips.sorted().first()
            else -> "$realRepo.zip"
        }
        val note = when {
            zips.size == 1 -> "File ZIP terdeteksi: $zipName."
            zips.size > 1 -> "Ada ${zips.size} file ZIP di repository; dipakai $zipName. Ubah lewat tombol Ubah bila perlu."
            else -> "Belum ada file ZIP; upload pertama akan membuat $zipName."
        }
        return NewRepoInfo(CustomRepo(label, realOwner, realRepo, zipName, branch), note)
    }

    private fun showAddRepoDialog() {
        if (!api.configured()) { showGithubAccountDialog(); return }
        if (api.customRepos().size >= 10) {
            Toast.makeText(host, "Maksimal 10 repository tambahan.", Toast.LENGTH_LONG).show()
            return
        }
        val box = formBox()
        val link = addField(box, "Link repository, mis. https://github.com/pemilik/nama-repo", uri = true)
        val name = addField(box, "Nama label, mis. Aplikasi Kasir")
        box.addView(label(
            "Token GitHub Anda harus punya akses ke repository ini (Contents: Read and write, Actions: Read-only). " +
                "Repository perlu workflow yang berjalan saat file ZIP di-push ke branch default.",
            11f, secondaryText()
        ).apply { setPadding(0, dp(4), 0, 0) })
        val actions = dialogActions("Batal", "Tambah")
        box.addView(actions.first)
        val dialog = AlertDialog.Builder(host).setTitle("Tambah repository").setView(ScrollView(host).apply { addView(box) }).create()
        actions.second.setOnClickListener { dialog.dismiss() }
        actions.third.setOnClickListener {
            val parsed = api.parseRepoLink(link.text.toString())
            val labelText = name.text.toString().trim()
            if (parsed == null) {
                Toast.makeText(host, "Link repository tidak valid. Contoh: https://github.com/pemilik/nama-repo", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (labelText.isBlank() || labelText.length > 30) {
                Toast.makeText(host, "Nama label wajib diisi (maksimal 30 karakter).", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (api.repositories.any { it.equals(labelText, ignoreCase = true) }) {
                Toast.makeText(host, "Nama label sudah dipakai repository lain.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (api.repositories.any { api.repositorySlug(it).equals(parsed.second, ignoreCase = true) }) {
                Toast.makeText(host, "Repository dengan nama itu sudah ada di daftar.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            actions.third.isEnabled = false
            actions.third.alpha = 0.5f
            actions.third.text = "Memeriksa…"
            executor.execute {
                try {
                    val info = inspectNewRepo(parsed.first, parsed.second, labelText)
                    main.post {
                        api.addCustomRepo(info.repo)
                        dialog.dismiss()
                        rebuildCards()
                        selectRepo(labelText)
                        renderAccountTab()
                        Toast.makeText(host, "$labelText ditambahkan. ${info.note}", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    main.post {
                        monitor.reportError(e)
                        actions.third.isEnabled = true
                        actions.third.alpha = 1f
                        actions.third.text = "Tambah"
                        Toast.makeText(host, e.message ?: "Gagal memeriksa repository", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        dialog.showStyled()
    }

    private fun showEditRepoDialog(displayName: String) {
        val current = api.customRepos().firstOrNull { it.displayName == displayName } ?: return
        val box = formBox()
        val nameField = addField(box, "Nama label", current.displayName)
        val zipField = addField(box, "Nama file ZIP di repository", current.zipName)
        box.addView(label(
            "File ZIP yang Anda pilih saat upload selalu diganti namanya menjadi nama file ZIP ini di repository.",
            11f, secondaryText()
        ).apply { setPadding(0, dp(4), 0, 0) })
        val actions = dialogActions("Batal", "Simpan")
        box.addView(actions.first)
        val dialog = AlertDialog.Builder(host).setTitle("Ubah ${current.displayName}").setView(ScrollView(host).apply { addView(box) }).create()
        actions.second.setOnClickListener { dialog.dismiss() }
        actions.third.setOnClickListener {
            val newName = nameField.text.toString().trim()
            val newZip = zipField.text.toString().trim()
            if (newName.isBlank() || newName.length > 30) {
                Toast.makeText(host, "Nama label wajib diisi (maksimal 30 karakter).", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (api.repositories.any { it != displayName && it.equals(newName, ignoreCase = true) }) {
                Toast.makeText(host, "Nama label sudah dipakai repository lain.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (!Regex("[A-Za-z0-9._-]+\\.zip", RegexOption.IGNORE_CASE).matches(newZip)) {
                Toast.makeText(host, "Nama file ZIP harus berakhiran .zip dan hanya berisi huruf, angka, titik, minus, atau garis bawah.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            api.updateCustomRepo(displayName, CustomRepo(newName, current.owner, current.repo, newZip, current.branch))
            if (githubSelectedRepo == displayName) { githubSelectedRepo = newName; api.prefs.edit().putString("selected_repo", newName).apply() }
            historyCache.remove(current.repo)
            dialog.dismiss()
            rebuildChips()
            rebuildCards()
            renderGithubPage()
            renderAccountTab()
        }
        dialog.showStyled()
    }

    private fun confirmRemoveRepo(displayName: String) {
        val slug = api.repositorySlug(displayName)
        AlertDialog.Builder(host)
            .setTitle("Hapus dari aplikasi?")
            .setMessage("$displayName akan dihapus dari daftar di RepoDeck. Repository di GitHub tidak diubah.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                api.removeCustomRepo(displayName)
                api.prefs.edit()
                    .remove("github_pending_$slug")
                    .remove("github_auto_build_commit_$slug")
                    .remove("github_auto_build_commit_time_$slug")
                    .remove("github_auto_build_run_$slug")
                    .remove("github_last_seen_$slug")
                    .remove("github_app_commits_$slug")
                    .remove("github_last_result_$slug")
                    .remove("github_zip_identity_$slug")
                    .apply()
                monitor.runsCache.remove(slug)
                historyCache.remove(slug)
                if (githubSelectedRepo == displayName) githubSelectedRepo = api.repositories.firstOrNull().orEmpty()
                rebuildChips()
                rebuildCards()
                renderGithubPage()
                renderAccountTab()
            }
            .showStyled()
    }

}
