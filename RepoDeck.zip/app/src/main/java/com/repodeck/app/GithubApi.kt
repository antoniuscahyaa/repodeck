package com.repodeck.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.Duration
import java.time.Instant
import java.util.zip.ZipInputStream
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** File hasil unduhan: nama yang benar-benar tersimpan dan Uri untuk membukanya (null bila tidak tersedia). */
class SavedFile(val name: String, val uri: Uri?)

/** Repository tambahan yang ditambahkan pengguna (link + label). */
class CustomRepo(val displayName: String, val owner: String, val repo: String, val zipName: String, val branch: String)

/** Dilempar saat GitHub membatasi request. [untilMs] = kapan request boleh dilanjutkan. */
class GithubRateLimitException(val untilMs: Long, message: String) : IllegalStateException(message)

/**
 * Lapisan jaringan + penyimpanan GitHub (tanpa UI): akun/token terenkripsi, request REST
 * dengan cache ETag (respons 304 tidak dihitung ke kuota), deteksi rate limit, serta
 * download dan penyimpanan artifact/log ke folder Downloads.
 */
class GithubApi(context: Context) {

    private val appContext: Context = context.applicationContext

    val prefs by lazy { appContext.getSharedPreferences("repodeck_github", Context.MODE_PRIVATE) }

    private val builtInRepos: List<String> = emptyList()

    /** Nama tab yang tampil ke pengguna: tiga bawaan, lalu repository tambahan. */
    val repositories: List<String> get() = builtInRepos + customRepos().map { it.displayName }

    // ---------------------------------------------------------------- repository tambahan

    @Volatile private var customCache: List<CustomRepo>? = null

    fun customRepos(): List<CustomRepo> {
        val cached = customCache
        if (cached != null) return cached
        val list = mutableListOf<CustomRepo>()
        try {
            val arr = JSONArray(prefs.getString("custom_repos", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name")
                val owner = o.optString("owner")
                val repo = o.optString("repo")
                if (name.isBlank() || owner.isBlank() || repo.isBlank()) continue
                list.add(CustomRepo(name, owner, repo, o.optString("zip").ifBlank { "$repo.zip" }, o.optString("branch").ifBlank { "main" }))
            }
        } catch (_: Exception) {
        }
        customCache = list
        return list
    }

    private fun saveCustomRepos(list: List<CustomRepo>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("name", it.displayName).put("owner", it.owner).put("repo", it.repo)
                .put("zip", it.zipName).put("branch", it.branch))
        }
        prefs.edit().putString("custom_repos", arr.toString()).apply()
        customCache = list
    }

    fun addCustomRepo(repo: CustomRepo) = saveCustomRepos(customRepos() + repo)

    fun updateCustomRepo(oldName: String, repo: CustomRepo) =
        saveCustomRepos(customRepos().map { if (it.displayName == oldName) repo else it })

    /** Memindahkan repository tambahan ke posisi [toIndex] (urutan pill di tab Repo). */
    fun moveCustomRepo(displayName: String, toIndex: Int) {
        val list = customRepos().toMutableList()
        val from = list.indexOfFirst { it.displayName == displayName }
        if (from < 0) return
        val item = list.removeAt(from)
        list.add(toIndex.coerceIn(0, list.size), item)
        saveCustomRepos(list)
    }

    fun removeCustomRepo(displayName: String) = saveCustomRepos(customRepos().filter { it.displayName != displayName })

    fun isCustom(displayName: String): Boolean = customRepos().any { it.displayName == displayName }

    /** Pemilik repository: pemilik khusus untuk repository tambahan, selain itu pemilik akun. */
    fun ownerFor(repoSlug: String): String = customRepos().firstOrNull { it.repo == repoSlug }?.owner ?: owner()

    /** Branch yang dipakai untuk upload dan pembacaan riwayat. */
    fun branchFor(repoSlug: String): String = customRepos().firstOrNull { it.repo == repoSlug }?.branch ?: "main"

    /** Mengambil pemilik dan nama repo dari link GitHub (https://github.com/pemilik/repo, git@..., atau pemilik/repo). */
    fun parseRepoLink(input: String): Pair<String, String>? {
        var s = input.trim().removePrefix("https://").removePrefix("http://").removePrefix("www.")
        s = when {
            s.startsWith("github.com/") -> s.removePrefix("github.com/")
            s.startsWith("git@github.com:") -> s.removePrefix("git@github.com:")
            else -> s
        }
        val parts = s.split('/', '?', '#').filter { it.isNotBlank() }
        if (parts.size < 2) return null
        val owner = parts[0]
        val repo = parts[1].removeSuffix(".git")
        val valid = Regex("[A-Za-z0-9_.-]+")
        if (!valid.matches(owner) || !valid.matches(repo)) return null
        return Pair(owner, repo)
    }

    // ---------------------------------------------------------------- repository

    // Tab title remains user-friendly; API calls use the actual repository slug.
    fun displayNameForSlug(repoSlug: String): String =
        customRepos().firstOrNull { it.repo == repoSlug }?.displayName ?: repoSlug

    fun repositorySlug(displayName: String): String =
        customRepos().firstOrNull { it.displayName == displayName }?.repo ?: displayName

    fun canonicalZipName(displayName: String): String =
        customRepos().firstOrNull { it.displayName == displayName }?.zipName
            ?: throw IllegalArgumentException("Repository tidak dikenali: $displayName")

    // ---------------------------------------------------------------- akun

    @Volatile private var tokenCache: String? = null

    fun owner(): String = prefs.getString("owner", "")?.trim().orEmpty()

    /** Pengaturan otomatisasi (semua aktif secara bawaan): opt_auto_download, opt_offer_install, opt_background_monitor. */
    fun option(key: String): Boolean = prefs.getBoolean(key, true)

    fun setOption(key: String, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }

    fun configured(): Boolean = owner().isNotBlank() && token().isNotBlank()

    /** Pemeriksaan murah (tanpa dekripsi Keystore) untuk dipakai di loop polling. */
    fun hasCredentials(): Boolean = owner().isNotBlank() && prefs.contains("token_enc")

    fun saveAccount(owner: String, token: String) {
        saveToken(token)
        prefs.edit().putString("owner", owner).apply()
        clearCaches()
    }

    fun clearAccess() {
        prefs.edit().remove("owner").remove("token_enc").remove("token_iv").apply()
        clearCaches()
    }

    private fun clearCaches() {
        tokenCache = null
        synchronized(etagCache) { etagCache.clear() }
        rateLimitedUntilMs = 0L
        rateLimitRemaining = -1
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey("repodeck_github_key", null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            "repodeck_github_key", android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun saveToken(token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("token_enc", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("token_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }

    /** Token didekripsi sekali lalu disimpan di memori (hindari operasi Keystore tiap request). */
    fun token(): String {
        val cached = tokenCache
        if (cached != null) return cached
        val decrypted = try {
            val enc = prefs.getString("token_enc", null) ?: return ""
            val iv = Base64.decode(prefs.getString("token_iv", ""), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(Base64.decode(enc, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) { "" }
        if (decrypted.isNotBlank()) tokenCache = decrypted
        return decrypted
    }

    /** Rahasia tambahan (mis. token khusus halaman Lawn) dienkripsi dengan kunci Keystore yang sama. Nilai kosong = hapus. */
    fun saveSecret(name: String, value: String) {
        if (value.isBlank()) { prefs.edit().remove("${name}_enc").remove("${name}_iv").apply(); return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("${name}_enc", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("${name}_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }

    fun readSecret(name: String): String = try {
        val enc = prefs.getString("${name}_enc", null)
        if (enc == null) "" else {
            val iv = Base64.decode(prefs.getString("${name}_iv", ""), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(Base64.decode(enc, Base64.NO_WRAP)), Charsets.UTF_8)
        }
    } catch (_: Exception) { "" }

    // ---------------------------------------------------------------- rate limit & ETag

    @Volatile var rateLimitedUntilMs = 0L
        private set

    /** Sisa kuota terakhir yang dilaporkan GitHub (-1 = belum diketahui). */
    @Volatile var rateLimitRemaining = -1
        private set

    fun isRateLimited(): Boolean = System.currentTimeMillis() < rateLimitedUntilMs

    fun rateLimitMessage(untilMs: Long): String {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(untilMs))
        return "Batas request GitHub tercapai. Dilanjutkan otomatis pukul $time."
    }

    private class CachedResponse(val etag: String, val body: String)

    private val etagCache = object : LinkedHashMap<String, CachedResponse>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedResponse>?): Boolean = size > 48
    }

    private class Reply(
        val code: Int, val body: String, val etag: String?,
        val remaining: Int, val resetEpochSec: Long, val retryAfterSec: Long
    )

    private fun replyOf(conn: HttpURLConnection, code: Int, body: String) = Reply(
        code, body,
        conn.getHeaderField("ETag"),
        conn.getHeaderField("x-ratelimit-remaining")?.toIntOrNull() ?: -1,
        conn.getHeaderField("x-ratelimit-reset")?.toLongOrNull() ?: 0L,
        conn.getHeaderField("retry-after")?.toLongOrNull() ?: 0L
    )

    private fun errorMessage(reply: Reply): String =
        try { JSONObject(reply.body).optString("message", "HTTP ${reply.code}") } catch (_: Exception) { "HTTP ${reply.code}" }

    private fun checkNotRateLimited() {
        val until = rateLimitedUntilMs
        if (System.currentTimeMillis() < until) throw GithubRateLimitException(until, rateLimitMessage(until))
    }

    /** Mengubah balasan error menjadi [GithubRateLimitException] bila itu pembatasan GitHub. */
    private fun throwIfRateLimited(reply: Reply) {
        val message = errorMessage(reply)
        val limited = reply.code == 429 ||
            (reply.code == 403 && (reply.remaining == 0 || reply.retryAfterSec > 0L || message.contains("rate limit", ignoreCase = true)))
        if (!limited) return
        val now = System.currentTimeMillis()
        val until = when {
            reply.retryAfterSec > 0L -> now + reply.retryAfterSec * 1000L
            reply.resetEpochSec > 0L -> reply.resetEpochSec * 1000L
            else -> now + 60_000L
        }.coerceAtLeast(now + 5_000L)
        rateLimitedUntilMs = until
        throw GithubRateLimitException(until, rateLimitMessage(until))
    }

    private fun noteQuota(reply: Reply) {
        if (reply.remaining >= 0) rateLimitRemaining = reply.remaining
    }

    private fun HttpURLConnection.applyGithubHeaders(tokenOverride: String? = null) {
        setRequestProperty("Accept", "application/vnd.github+json")
        setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        setRequestProperty("Authorization", "Bearer ${tokenOverride?.takeIf { it.isNotBlank() } ?: token()}")
        setRequestProperty("User-Agent", "RepoDeck-Android")
    }

    // ---------------------------------------------------------------- request

    /**
     * GET dikirim dengan If-None-Match bila respons sebelumnya punya ETag. Balasan 304
     * tidak mengurangi kuota API dan mengembalikan isi cache.
     */
    fun request(path: String, method: String = "GET", body: JSONObject? = null, tokenOverride: String? = null): String {
        checkNotRateLimited()
        val cacheable = method == "GET" && body == null
        val cached = if (cacheable) synchronized(etagCache) { etagCache[path] } else null
        val conn = (URL("https://api.github.com$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 20000; readTimeout = 30000
            applyGithubHeaders(tokenOverride)
            if (cached != null) setRequestProperty("If-None-Match", cached.etag)
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        if (body != null) conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = if (code == 304) "" else stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val reply = replyOf(conn, code, text)
        conn.disconnect()
        noteQuota(reply)
        if (code == 304 && cached != null) return cached.body
        if (code !in 200..299) {
            throwIfRateLimited(reply)
            throw IllegalStateException("GitHub API $code: ${errorMessage(reply)}")
        }
        val etag = reply.etag
        // Respons besar (mis. isi blob) tidak di-cache agar memori tidak membengkak.
        if (cacheable && !etag.isNullOrBlank() && reply.body.length <= 1_500_000) synchronized(etagCache) { etagCache[path] = CachedResponse(etag, reply.body) }
        return reply.body
    }

    fun requestWithProgress(path: String, bodyBytes: ByteArray, tokenOverride: String? = null, onProgress: (Int, Long, Long) -> Unit): String {
        checkNotRateLimited()
        val conn = (URL("https://api.github.com$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"; connectTimeout = 30000; readTimeout = 60000
            doOutput = true
            setFixedLengthStreamingMode(bodyBytes.size)
            applyGithubHeaders(tokenOverride)
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        conn.outputStream.use { output ->
            val chunk = 16 * 1024
            var offset = 0
            while (offset < bodyBytes.size) {
                val count = minOf(chunk, bodyBytes.size - offset)
                output.write(bodyBytes, offset, count)
                offset += count
                onProgress((offset * 100L / bodyBytes.size.coerceAtLeast(1)).toInt(), offset.toLong(), bodyBytes.size.toLong())
            }
            output.flush()
        }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        val reply = replyOf(conn, code, text)
        conn.disconnect()
        noteQuota(reply)
        if (code !in 200..299) {
            throwIfRateLimited(reply)
            throw IllegalStateException("GitHub API $code: ${errorMessage(reply)}")
        }
        return reply.body
    }

    /** Mengambil teks log satu job. Tidak di-cache (ukurannya besar). */
    fun fetchJobLog(owner: String, repoSlug: String, jobId: Long): String {
        checkNotRateLimited()
        val conn = (URL("https://api.github.com/repos/$owner/$repoSlug/actions/jobs/$jobId/logs").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; instanceFollowRedirects = true; connectTimeout = 20000; readTimeout = 30000
            applyGithubHeaders()
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val reply = replyOf(conn, code, error)
            conn.disconnect()
            noteQuota(reply)
            throwIfRateLimited(reply)
            if (code == 404) throw IllegalStateException("Log belum tersedia dari GitHub. Jika job masih berjalan, coba lagi setelah job selesai.")
            throw IllegalStateException("Tidak dapat mengambil log (HTTP $code): $error")
        }
        val log = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return log
    }

    // ---------------------------------------------------------------- download

    /** Jumlah entri dalam ZIP; 0 untuk arsip kosong, -1 bila bukan ZIP yang valid. */
    fun zipEntryCount(zip: File): Int = try {
        var count = 0
        ZipInputStream(zip.inputStream().buffered()).use { z -> while (z.nextEntry != null) count++ }
        count
    } catch (_: Exception) {
        -1
    }

    fun downloadArchiveToCache(path: String, fileName: String): File {
        checkNotRateLimited()
        val temp = File(appContext.cacheDir, fileName)
        val conn = (URL("https://api.github.com$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; instanceFollowRedirects = true; connectTimeout = 30000; readTimeout = 120000
            applyGithubHeaders()
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val reply = replyOf(conn, code, error)
            conn.disconnect()
            noteQuota(reply)
            throwIfRateLimited(reply)
            throw IllegalStateException("HTTP $code: ${errorMessage(reply)}")
        }
        conn.inputStream.use { input -> FileOutputStream(temp).use { output ->
            val buffer = ByteArray(32 * 1024)
            while (true) { val count = input.read(buffer); if (count < 0) break; output.write(buffer, 0, count) }
        } }
        conn.disconnect()
        return temp
    }

    /**
     * Menyimpan file ke Downloads/RepoDeck/<folder>/<repo>/. Nama dan Uri dibaca langsung dari
     * file yang baru dibuat (bukan dicari ulang), sehingga tetap benar walau MediaStore mengganti nama.
     */
    fun saveDownload(temp: File, repoSlug: String, folder: String, requestedName: String): SavedFile {
        val safeRepo = repoSlug.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val safeName = requestedName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/RepoDeck/$folder/$safeRepo/"
            val resolver = appContext.contentResolver
            val base = safeName.substringBeforeLast('.', safeName)
            val ext = safeName.substringAfterLast('.', "")
            var candidate = safeName
            var suffix = 1
            while (true) {
                val cursor = resolver.query(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    arrayOf(android.provider.MediaStore.Downloads._ID),
                    "${android.provider.MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${android.provider.MediaStore.MediaColumns.RELATIVE_PATH}=?",
                    arrayOf(candidate, relativePath), null
                )
                val exists = cursor?.use { it.moveToFirst() } ?: false
                if (!exists) break
                candidate = if (ext.isBlank()) "$base ($suffix)" else "$base ($suffix).$ext"
                suffix++
            }
            val values = ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, candidate)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak dapat membuat file di folder Downloads")
            try {
                resolver.openOutputStream(uri)?.use { output -> temp.inputStream().use { it.copyTo(output) } }
                    ?: throw IllegalStateException("Tidak dapat menulis file hasil download")
                val done = ContentValues().apply { put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
            val actualName = (try {
                resolver.query(uri, arrayOf(android.provider.MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null }
            } catch (_: Exception) { null }) ?: candidate
            return SavedFile(actualName, uri)
        } else {
            val root = File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "RepoDeck/$folder/$safeRepo")
            if (!root.exists() && !root.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder download")
            val base = safeName.substringBeforeLast('.', safeName)
            val ext = safeName.substringAfterLast('.', "")
            var candidate = safeName
            var target = File(root, candidate)
            var suffix = 1
            while (target.exists()) {
                candidate = if (ext.isBlank()) "$base ($suffix)" else "$base ($suffix).$ext"
                target = File(root, candidate); suffix++
            }
            temp.copyTo(target, overwrite = false)
            val uri = try {
                androidx.core.content.FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", target)
            } catch (_: Exception) { null }
            return SavedFile(candidate, uri)
        }
    }

    /**
     * Mengekstrak APK dari artifact (ZIP) ke folder aplikasi (Download/RepoDeck/Apk/<repo>/) dan
     * mengembalikan APK terbaik: release bertanda tangan, lalu debug, lalu yang lain. Null bila tidak ada APK.
     */
    fun extractApk(zip: File, repoSlug: String): File? {
        val safeRepo = repoSlug.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "RepoDeck/Apk/$safeRepo")
        val extracted = mutableListOf<File>()
        try {
            ZipInputStream(zip.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.substringAfterLast('/')
                    if (!entry.isDirectory && name.endsWith(".apk", ignoreCase = true)) {
                        if (!dir.exists() && !dir.mkdirs()) return null
                        val out = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                        FileOutputStream(out).use { zis.copyTo(it) }
                        extracted.add(out)
                    }
                    entry = zis.nextEntry
                }
            }
        } catch (_: Exception) {
            return null
        }
        // Bersihkan APK lama (> 14 hari) agar penyimpanan tidak membengkak.
        val cutoff = System.currentTimeMillis() - 14L * 24L * 60L * 60L * 1000L
        dir.listFiles()?.filter { it.lastModified() < cutoff }?.forEach { it.delete() }
        return extracted.maxByOrNull { apkScore(it.name) }
    }

    private fun apkScore(name: String): Int {
        val n = name.lowercase(Locale.ROOT)
        var score = 0
        if (n.contains("release")) score += 4
        if (n.contains("debug")) score += 2
        if (n.contains("unsigned")) score -= 8
        return score
    }

    fun savedFileUri(repoSlug: String, folder: String, savedName: String): Uri {
        val safeRepo = repoSlug.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/RepoDeck/$folder/$safeRepo/"
            val cursor = appContext.contentResolver.query(
                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(android.provider.MediaStore.MediaColumns._ID),
                "${android.provider.MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${android.provider.MediaStore.MediaColumns.RELATIVE_PATH}=?",
                arrayOf(savedName, relativePath),
                "${android.provider.MediaStore.MediaColumns.DATE_ADDED} DESC"
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val id = it.getLong(0)
                    return android.content.ContentUris.withAppendedId(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, id
                    )
                }
            }
            throw IllegalStateException("File hasil download tidak ditemukan di Downloads")
        } else {
            val file = File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "RepoDeck/$folder/$safeRepo/$savedName")
            if (!file.exists()) throw IllegalStateException("File hasil download tidak ditemukan")
            androidx.core.content.FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
        }
    }

    fun fileMimeType(fileName: String): String = when {
        fileName.endsWith(".apk", true) -> "application/vnd.android.package-archive"
        fileName.endsWith(".zip", true) -> "application/zip"
        fileName.endsWith(".txt", true) || fileName.endsWith(".log", true) -> "text/plain"
        else -> "application/octet-stream"
    }

    // ---------------------------------------------------------------- format

    fun formatTimestamp(isoTimestamp: String): String {
        return try {
            val instant = Instant.parse(isoTimestamp)
            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
                .format(Date.from(instant))
        } catch (_: Exception) {
            isoTimestamp.replace("T", " ").removeSuffix("Z").take(16)
        }
    }

    fun formatDuration(startedAt: String, completedAt: String = ""): String {
        return try {
            val start = Instant.parse(startedAt)
            val end = if (completedAt.isNotBlank()) Instant.parse(completedAt) else Instant.now()
            val seconds = Duration.between(start, end).seconds.coerceAtLeast(0)
            "%02d:%02d".format(seconds / 60, seconds % 60)
        } catch (_: Exception) { "—" }
    }
}
