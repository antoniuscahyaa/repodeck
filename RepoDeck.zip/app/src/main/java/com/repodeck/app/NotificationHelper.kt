package com.repodeck.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object NotificationHelper {

    const val CHANNEL_ID = "repodeck_default"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "RepoDeck", NotificationManager.IMPORTANCE_DEFAULT
            )
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    /** Menampilkan notifikasi yang langsung membuka file hasil download saat diketuk. */
    fun showFile(
        context: Context,
        id: Int,
        title: String,
        text: String,
        fileUri: android.net.Uri,
        mimeType: String,
        installUri: android.net.Uri? = null
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        // Use the file URI itself as the PendingIntent target. Avoid a chooser wrapper
        // so the notification tap cannot fall back to RepoDeck's launcher activity.
        val openFile = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileUri, mimeType)
            clipData = android.content.ClipData.newUri(context.contentResolver, "Hasil download", fileUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            data = fileUri
        }
        val pending = PendingIntent.getActivity(
            context, id, openFile,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_repodeck)
            .setColor(0xFF1E88E5.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pending)
            .setAutoCancel(true)
        if (installUri != null) {
            // Tombol "Install": membuka installer sistem untuk APK hasil build.
            val install = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(installUri, "application/vnd.android.package-archive")
                clipData = android.content.ClipData.newRawUri("APK", installUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            builder.addAction(
                0, "Install",
                PendingIntent.getActivity(context, id + 1, install, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        }
        NotificationManagerCompat.from(context).notify(id, builder.build())
    }

    /** Menampilkan notifikasi dengan logo RepoDeck. Butuh izin notifikasi di Android 13+. */
    fun show(context: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_repodeck)
            .setColor(0xFF1E88E5.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(id, notif)
    }
}
