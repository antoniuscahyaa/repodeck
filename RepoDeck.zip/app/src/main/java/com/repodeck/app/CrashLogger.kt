package com.repodeck.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Menyimpan stack trace crash terakhir ke file internal supaya bisa ditampilkan saat aplikasi
 * dibuka lagi. Jika aplikasi mati tanpa laporan, penyebabnya bukan exception (mis. proses
 * dimatikan Android karena memori atau baterai).
 */
object CrashLogger {
    private const val FILE_NAME = "last_crash.txt"
    @Volatile private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            write(app, "FATAL", thread.name, throwable)
            if (previous != null) previous.uncaughtException(thread, throwable)
        }
    }

    /** Mencatat error yang ditangkap (tidak membuat aplikasi berhenti). */
    fun record(context: Context, throwable: Throwable, where: String = "") {
        write(context.applicationContext, "NON-FATAL", where, throwable)
    }

    private fun write(app: Context, kind: String, where: String, throwable: Throwable) {
        try {
            val file = File(app.filesDir, FILE_NAME)
            // Laporan FATAL tidak ditimpa oleh catatan NON-FATAL.
            if (kind != "FATAL" && file.exists() && file.readText().startsWith("[FATAL]")) return
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            file.writeText("[$kind] $time · $where\n$sw".take(12000))
        } catch (_: Throwable) {
        }
    }

    fun read(context: Context): String? {
        val file = File(context.filesDir, FILE_NAME)
        return if (file.exists()) file.readText().takeIf { it.isNotBlank() } else null
    }

    fun clear(context: Context) {
        File(context.filesDir, FILE_NAME).delete()
    }
}
