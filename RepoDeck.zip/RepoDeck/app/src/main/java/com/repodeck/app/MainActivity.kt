package com.repodeck.app

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils

/**
 * Cangkang aplikasi RepoDeck: tiga tab (Repo, Build, Akun) dengan navigasi bawah.
 * Seluruh logika GitHub ada di [GithubManagerPage]; kelas ini menyediakan helper tampilan dan peluncur file.
 */
class MainActivity : AppCompatActivity() {

    private val githubPageDelegate = lazy { GithubManagerPage(this) }
    private val githubPage by githubPageDelegate

    private val githubZipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) githubPage.confirmGithubZipUpload(uri)
    }
    private val githubLogSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) githubPage.saveLogTo(uri)
    }

    private lateinit var content: FrameLayout
    private val tabViews = arrayOfNulls<View>(3)
    private val navIcons = arrayOfNulls<ImageView>(3)
    private val navCaptions = arrayOfNulls<TextView>(3)

    internal fun launchGithubZipPicker() =
        githubZipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))

    internal fun launchGithubLogSaver(fileName: String) = githubLogSaver.launch(fileName)

    /** Halaman GitHub selalu aktif selama Activity hidup (tab hanya mengganti tampilan). */
    internal fun isGithubSection(): Boolean = !isFinishing && !isDestroyed

    internal fun showStyledDialog(dialog: AlertDialog) = dialog.showStyled()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLogger.install(this)
        NotificationHelper.createChannel(this)
        requestNotificationPermission()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surfaceColor())
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(View(this).apply { setBackgroundColor(dividerColor()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, hairline()))
        root.addView(buildNav(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)))
        setContentView(root)

        tabViews[0] = githubPage.buildPage()
        tabViews[1] = githubPage.buildBuildTab()
        tabViews[2] = githubPage.buildAccountTab()
        selectTab(if (githubPage.api.configured()) 0 else 2)
        githubPage.startMonitoring()
        showCrashReportIfAny()
    }

    override fun onDestroy() {
        if (githubPageDelegate.isInitialized()) githubPage.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- navigasi bawah

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(surfaceColor())
        }
        val specs = listOf(
            Pair("Repo", R.drawable.ic_tab_repo),
            Pair("Build", R.drawable.ic_tab_build),
            Pair("Akun", R.drawable.ic_tab_user)
        )
        specs.forEachIndexed { index, spec ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                contentDescription = spec.first
                setOnClickListener { selectTab(index) }
            }
            val icon = ImageView(this).apply { setImageResource(spec.second) }
            val caption = TextView(this).apply { text = spec.first; textSize = 12f }
            item.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(caption, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) })
            navIcons[index] = icon
            navCaptions[index] = caption
            bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        return bar
    }

    /** 0 = Repo, 1 = Build, 2 = Akun. */
    internal fun selectTab(index: Int) {
        if (index < 0 || index > 2) return
        content.removeAllViews()
        tabViews[index]?.let {
            content.addView(it, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        for (i in 0..2) {
            val active = i == index
            val color = if (active) accentColor() else secondaryText()
            navIcons[i]?.imageTintList = ColorStateList.valueOf(color)
            navCaptions[i]?.setTextColor(color)
            navCaptions[i]?.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        }
        when (index) {
            1 -> githubPage.refreshBuildTab(true)
            2 -> githubPage.renderAccountTab()
        }
    }

    // ---------------------------------------------------------------- izin & laporan error

    private fun requestNotificationPermission() {
        val prefs = githubPage.api.prefs
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("notification_permission_requested", false)
        ) {
            prefs.edit().putBoolean("notification_permission_requested", true).apply()
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7403)
        }
    }

    private fun showCrashReportIfAny() {
        val report = CrashLogger.read(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("Laporan error terakhir")
            .setMessage(report.take(3500))
            .setPositiveButton("Salin") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("RepoDeck crash", report))
                CrashLogger.clear(this)
            }
            .setNegativeButton("Tutup") { _, _ -> CrashLogger.clear(this) }
            .showStyled()
    }

    internal fun queryDisplayName(uri: Uri): String {
        var result = "upload.zip"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) result = c.getString(0) ?: result
        }
        return result
    }

    // ---------------------------------------------------------------- helper tampilan (dipakai GithubManagerPage)

    internal fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    internal fun sectionTitle(text: String, size: Float = 17f): TextView = label(text, size, primaryText(), true)

    internal fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    internal fun actionSetting(title: String, description: String, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = cardBackground()
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 14f, primaryText(), true))
        texts.addView(label(description, 11f, secondaryText()).apply { setPadding(0, dp(5), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(label("›", 25f, secondaryText()))
        return row.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(9) }
        }
    }

    internal fun infoCard(title: String, description: String, action: String?, onClick: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = cardBackground()
        }
        box.addView(sectionTitle(title, 15f))
        box.addView(label(description, 12f, secondaryText()).apply {
            setPadding(0, dp(6), 0, if (action == null) 0 else dp(10))
        })
        if (action != null) {
            box.addView(label(action, 12f, accentColor(), true).apply { setOnClickListener { onClick() } })
            box.setOnClickListener { onClick() }
        }
        return box
    }

    internal fun pressable(fill: Int, radiusDp: Int, stroke: Boolean): android.graphics.drawable.Drawable {
        val r = dp(radiusDp).toFloat()
        val base = roundedBackground(fill, r).apply { if (stroke) setStroke(hairline(), dividerColor()) }
        val mask = roundedBackground(Color.BLACK, r)
        return RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(primaryText(), 36)), base, mask)
    }

    internal fun styleField(et: EditText, onCard: Boolean = false) {
        et.background = roundedBackground(if (onCard) surfaceColor() else cardColor(), dp(12).toFloat()).apply {
            setStroke(hairline(), dividerColor())
        }
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.setTextColor(primaryText())
        et.setHintTextColor(secondaryText())
    }

    private fun AlertDialog.Builder.showStyled(): AlertDialog = create().also { it.showStyled() }

    private fun AlertDialog.showStyled() {
        show()
        window?.let { dialogWindow ->
            dialogWindow.setBackgroundDrawable(
                android.graphics.drawable.InsetDrawable(
                    roundedBackground(surfaceColor(), dp(26).toFloat()).apply { setStroke(hairline(), dividerColor()) },
                    dp(16)
                )
            )
            dialogWindow.setDimAmount(0.45f)
        }
        findViewById<View>(resources.getIdentifier("parentPanel", "id", "android"))?.setPadding(dp(10), dp(14), dp(10), dp(6))
        findViewById<TextView>(android.R.id.title)?.apply {
            setTextColor(primaryText())
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
        }
        findViewById<TextView>(android.R.id.message)?.apply {
            setTextColor(secondaryText())
            textSize = 14f
        }
        listOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL).forEach { which ->
            val b = getButton(which) ?: return@forEach
            val primary = which == AlertDialog.BUTTON_POSITIVE
            b.isAllCaps = false
            b.stateListAnimator = null
            b.textSize = 13f
            b.setTypeface(null, Typeface.BOLD)
            b.minHeight = dp(42)
            b.minWidth = dp(84)
            b.setPadding(dp(16), dp(8), dp(16), dp(8))
            b.setTextColor(if (primary) onAccent() else primaryText())
            b.background = pressable(if (primary) accentColor() else cardColor(), 14, !primary)
            (b.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
                lp.setMargins(dp(4), dp(4), dp(4), dp(8))
                b.layoutParams = lp
            }
        }
    }

    private fun hairline() = (0.8f * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    internal fun cardBackground() = roundedBackground(cardColor(), dp(16).toFloat()).apply {
        setStroke(hairline(), dividerColor())
    }

    internal fun roundedBackground(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    internal fun primaryText() = resolveColor(com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
    internal fun secondaryText() = resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF5F5F66.toInt())
    internal fun accentColor() = resolveColor(com.google.android.material.R.attr.colorPrimary, 0xFF1A73E8.toInt())
    internal fun onAccent() = resolveColor(com.google.android.material.R.attr.colorOnPrimary, Color.WHITE)
    internal fun cardColor() = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant, 0xFFF4F4F5.toInt())
    private fun surfaceColor() = resolveColor(com.google.android.material.R.attr.colorSurface, Color.WHITE)
    private fun dividerColor() = resolveColor(com.google.android.material.R.attr.colorOutlineVariant, 0xFFE8E8EA.toInt())

    private fun resolveColor(attr: Int, fallback: Int): Int {
        val value = android.util.TypedValue()
        return if (theme.resolveAttribute(attr, value, true)) {
            if (value.resourceId != 0) getColor(value.resourceId) else value.data
        } else fallback
    }
}
